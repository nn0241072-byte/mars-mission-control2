"""Offscreen regression checks for the NASA-based desktop UI."""
import os,sys,tempfile,time
from pathlib import Path
from unittest.mock import patch
os.environ['QT_QPA_PLATFORM']='offscreen'
sys.path.insert(0,str(Path(__file__).resolve().parent/'mars_mission_control'))
from PySide6.QtWidgets import QApplication
from PySide6.QtCore import QSettings,Qt,QThreadPool
from PySide6.QtTest import QTest
from PySide6.QtGui import QImage,QColor
from ui import main_window
from services.nasa_tiles import NasaTiles
from services.terrain import TerrainGrid
from storage.database import MissionDB
app=QApplication([])

def wait_for(predicate):
    deadline=time.monotonic()+5
    while not predicate() and time.monotonic()<deadline:QTest.qWait(20)
    assert predicate()

def terrain(a,b,cache):
    return TerrainGrid(-180,-90,180,90,65,33,[0.]*(65*33))

with tempfile.TemporaryDirectory() as tmp, patch.object(main_window,'fetch_terrain',terrain), patch.object(main_window,'fetch_weather',lambda:[]), patch.object(main_window.BackendClient,'start',lambda self:None), patch.object(NasaTiles,'load_metadata',lambda self:None):
    root=Path(tmp);main_window.DATA_DIR=root
    old=MissionDB(root/'mission.sqlite3');old.upsert_marker('OLD_PIXEL','station',25,30);old.close()
    QSettings.setPath(QSettings.Format.NativeFormat,QSettings.Scope.UserScope,tmp)
    w=main_window.MainWindow();w.show()
    try:
        wait_for(lambda:len(w.map.routes)==2)
        assert w.map.routes[0]['key']=='fastest'
        assert w.map.routes[1]['key']=='safest'
        assert w.map.routes[0]['radiation_usv'] is None
        assert w.route_list.count()==3
        w._route_from_list(1);assert w.selected_route=='safest'
        w.map.mode='a';w._map_click(350,350)
        assert w.map.routes==[]
        wait_for(lambda:bool(w.map.routes))
        assert w.map.routes[0]['points'][0]==(350,350)
        assert all(r['energy_wh']>0 and r['hours']>0 for r in w.map.routes)
        w.map.mode='astronaut';w._map_click(500,300)
        assert w.map.astronaut==(500,300)
        assert any(getattr(item,'name',None)=='ASTRONAUT-01' for item in w.map.overlay_items)
        with patch.object(main_window.QInputDialog,'getText',return_value=('Station',True)):
            w.map.mode='station';w._map_click(210,220)
        station=w.map.stations[-1]
        assert 'risk' not in station['reading']
        assert station['reading']['source']=='NASA MOLA'
        w.station_status.setCurrentIndex(4);w._set_station_status()
        marker=next(item for item in w.map.overlay_items if getattr(item,'name',None)==station['id'])
        assert marker.brush().color().name()=='#ff454f'
        w._delete_station();assert not w.map.stations
        w.photo_folder=root/'inbox';w.photo_folder.mkdir()
        image=QImage(64,32,QImage.Format.Format_RGB32);image.fill(QColor('orange'))
        image.save(str(w.photo_folder/'frame.png'));w._poll_drone_photos()
        assert w.photo_path.name=='frame.png'
        w._toggle_layer('show_temperature',True);assert w.map.show_temperature
        w._show_telemetry();w.moving_station='pending';w._mode('station_move')
        QTest.keyClick(w,Qt.Key.Key_Escape);app.processEvents()
        assert w.bottom_dock.isHidden() and w.map.mode=='pan' and w.moving_station is None
        old=MissionDB(root/'mission.sqlite3')
        assert [m['id'] for m in old.markers()]==['OLD_PIXEL'];old.close()
    finally:
        w.close();QThreadPool.globalInstance().waitForDone(1000)
    db=MissionDB(root/'mission_nasa.sqlite3')
    assert any(m['id']=='ASTRONAUT-01' and m['x']==500 for m in db.markers());db.close()
print('PASS: NASA routing, metrics, astronaut placement, station controls, photo inbox, Escape, and workspace persistence')
