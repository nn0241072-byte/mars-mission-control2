"""Run with: python main.py"""
import sys
from PySide6.QtWidgets import QApplication
from ui.main_window import MainWindow


def main():
    app=QApplication(sys.argv)
    app.setApplicationName('Mars Mission Control')
    window=MainWindow()
    window.show()
    return app.exec()

if __name__=='__main__':
    sys.exit(main())
