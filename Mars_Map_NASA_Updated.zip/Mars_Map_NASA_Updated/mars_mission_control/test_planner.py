import math
from pathlib import Path
import unittest
from services.terrain import TerrainGrid,read_float_tiff,distance_km
from services.planner import Mobility,plan_routes
from services.science import parse_weather,wind_color


class PlannerTest(unittest.TestCase):
    def test_real_nasa_tiff_and_georeferencing(self):
        data=(Path(__file__).parent/'tests/fixtures/nasa_mola_arsia_64.tif').read_bytes()
        width,height,values=read_float_tiff(data)
        self.assertEqual((width,height),(64,64))
        self.assertTrue(all(math.isfinite(z) for z in values))
        grid=TerrainGrid(-121,-9,-119,-7,width,height,values)
        self.assertTrue(10000<grid.sample((-120,-8))<22000)
        self.assertIsNone(grid.sample((0,0)))
        self.assertGreaterEqual(grid.resolution_km,.463)
        routes=plan_routes(grid,(-120.5,-8.6),(-119.5,-7.4))
        self.assertEqual(len(routes),2)
        for route in routes:
            self.assertEqual(route['lonlat'][0],(-120.5,-8.6))
            self.assertEqual(route['lonlat'][-1],(-119.5,-7.4))
            self.assertGreater(route['energy_wh'],0)
            self.assertGreater(route['hours'],0)
            self.assertIsNone(route['radiation_usv'])

    def test_paths_respond_to_actual_heights_not_random_bends(self):
        width=41;height=31
        # A ridge spanning the middle; a low pass is available to the north.
        values=[]
        for y in range(height):
            for x in range(width):
                values.append(max(0,1-abs(x-20)/5)*5000 if y>4 else 0)
        grid=TerrainGrid(0,0,.7,.5,width,height,values)
        a=grid.lonlat(15*width+2);b=grid.lonlat(15*width+38)
        flat=TerrainGrid(0,0,.7,.5,width,height,[0.]*(width*height))
        direct=plan_routes(flat,a,b)
        terrain=plan_routes(grid,a,b)
        self.assertEqual(len(terrain),2)
        self.assertGreater(terrain[0]['distance_km'],direct[0]['distance_km'])
        self.assertNotEqual(terrain[0]['lonlat'],direct[0]['lonlat'])
        self.assertLessEqual(terrain[1]['max_slope_deg'],15)
        self.assertEqual(terrain,plan_routes(grid,a,b))

    def test_nodata_barrier_does_not_create_fictional_route(self):
        values=[0.]*(15*15)
        for y in range(15):values[y*15+7]=math.nan
        grid=TerrainGrid(0,0,1,1,15,15,values)
        self.assertEqual(plan_routes(grid,grid.lonlat(7*15+1),grid.lonlat(7*15+13)),[])

    def test_geodesic_dateline_poles_and_same_cell(self):
        self.assertLess(distance_km((179.9,0),(-179.9,0)),12)
        self.assertAlmostEqual(distance_km((0,90),(120,90)),0,places=7)
        grid=TerrainGrid(179,-1,181,1,9,9,[0.]*81)
        routes=plan_routes(grid,(179.9,0),(-179.9,0))
        self.assertEqual(len(routes),2)
        self.assertLess(routes[0]['distance_km'],30)
        a=(179.901,0);b=(179.902,0)
        self.assertAlmostEqual(plan_routes(grid,a,b)[0]['distance_km'],distance_km(a,b))

    def test_point_weather_preserves_missing_values_and_date(self):
        row={'terrestrial_date':'2026-08-25','sol':'4995','min_temp':'-71','max_temp':'-5','wind_speed':'--','wind_direction':'--','min_gts_temp':'-84','max_gts_temp':'4'}
        record=parse_weather({'soles':[row]},'REMS',(137.44,-4.59),'NASA fixture')
        self.assertIsNone(record['wind_mps']);self.assertIsNone(record['wind_deg'])
        self.assertEqual(record['ground_max_c'],4)
        self.assertEqual(record['date'],'2026-08-25')
        self.assertTrue(record['archived'])
        self.assertEqual(wind_color(55),'#f05264')
        self.assertNotEqual(wind_color(10),wind_color(55))


if __name__=='__main__':unittest.main()
