# Mars Mission Control

Native Python / PySide6 mission planning over NASA Mars data. No Java or JavaScript integration is required.

## Launch on this computer

Backend (keep its existing process running if already started):

```powershell
cd C:\Users\Lenovo\Downloads\mars-map-main\mars-map-main
node server.mjs
```

Frontend (restart an existing window after code changes):

```powershell
cd C:\Users\Lenovo\Downloads\mars_mission_control_phase1\mars_mission_control
.\ui\.venv\Scripts\python.exe main.py
```

For a new environment, create a Python venv and install `requirements.txt`.

## Mission planning

- Select A or B in the left toolbar, then click anywhere on the Mars map. Route calculation runs in background workers; changing either point invalidates the previous result immediately.
- Fastest: A* minimizes modeled traversal time over the downloaded NASA MOLA height raster.
- Lower slope risk: A* increases the cost of sloping ground. Both profiles exclude sampled edge grades above 15 degrees. This is slope-based planning, not a guarantee of overall safety.
- Select a route in the list or on the map for distance, modeled travel time, modeled energy, total ascent, maximum sampled grade and slope-risk class. Identical routes on flat terrain are valid; no arbitrary bends are generated to manufacture alternatives.
- Select astronaut placement in the toolbar and click to place EVA-01. The marker persists and has its own visibility layer. It is a planned position, not astronaut telemetry.
- Movement profile defaults to an astronaut: 3 km/h base speed, 150 kg total mass, 250 W base consumption and 25% climbing efficiency. Rover defaults: 5 km/h, 500 kg, 500 W and 60% efficiency. These are editable mission assumptions, not NASA instrument readings. No specific suit or vehicle is modeled.
- NASA MOLA measurements are used for terrain. Time uses `distance / base_speed * (1 + (grade_degrees / 8)^2)`. Energy uses `base_power * time + mass * 3.71 * positive_ascent / (3600 * efficiency)` in Wh. The climbing term is an energy-equivalent model; it does not predict real suit battery or human metabolic consumption.
- The safety objective adds a grade penalty `1 + 12 * (grade / 5)^2`. Low/medium/high labels use maximum sampled grade below 5, 5-10, and at least 10 degrees respectively; these are project display categories.
- The displayed raster resolution is never finer than the source's approximately 463 m nominal equatorial resolution. Larger A/B extents are resampled more coarsely. Small rocks, crevasses, and sub-cell slopes are unresolved. A* searches a padded corridor, not the entire planetary surface. Routes are not validated navigation instructions.
- Antimeridian trips use an unwrapped short longitude interval and split elevation requests at the dateline; route drawings avoid a spurious line across the whole map.

## Layers and actual data coverage

**Categorical region map:** enabled by default, styled after the user's saved thematic-map reference. Seven discrete elevation bands color the planetary surface using a real global NASA MOLA raster (1440 x 720, approximately 15 km per cell at the equator). A compact fixed legend lists meters and the source. Missing pixels are transparent. This is elevation, not temperature; no global temperature field is fabricated. Toggle it in Layers. Temperature markers and the THEMIS image disable this overlay so their colors are not confused. Cursor readings show the underlying elevation when this map is active.

**Basemap:** NASA Trek Viking global mosaic, fetched by WMTS with zoom/pan, bounded concurrency, retries and disk caching. The local screenshot is not used.

**Terrain:** numeric float32 heights from the NASA Trek MOLA ImageServer advertised in NASA's own Mars configuration. Geographic bounds and coordinates use EPSG:104905. TIFF values are read as meters, not inferred from map colors. Requested regional rasters are cached in `~/.mars_mission_control/nasa-cache`.

**Temperature:** enable the temperature layer for dated Curiosity REMS / Perseverance MEDA measurement markers at approximate mission locations. Ground min/max temperatures are shown where supplied; otherwise air min/max are explicitly labeled as air. These are local observations, not a global forecast or rover tracking positions. Missing temperatures remain missing.

**THEMIS:** optional NASA Odyssey archived daytime infrared mosaic. Image brightness is not calibrated temperature in degrees Celsius; the layer is named accordingly. It is independent of the numeric temperature markers.

**Wind:** the NASA point weather feeds are fetched on startup and every 15 minutes. Missing wind speed/direction stays unknown. When both numeric fields exist, a colored local wind arrow and animated direction indicator are shown at the measurement location with the archived observation date. No global moving storm footprint is invented. The wind animation illustrates direction, not future storm motion. Project color bins: green below 15 m/s, yellow 15-30, orange 30-55, red at least 55 m/s. These are not NASA-approved danger thresholds. The currently checked feeds contain no numeric wind observations, so no wind animation is falsely displayed.

**Radiation:** no spatially resolved dose raster is configured. Curiosity RAD measurements are local and do not establish dose on arbitrary A/B routes. The minimum-radiation route is visibly unavailable and dose is shown as unknown; missing radiation is never treated as zero.

The previous seeded weather, random paths, simulated station hazard percentages, and default drone battery/altitude readings are no longer used. Mission station markers are editable planning objects; only available NASA terrain samples are attached to them. Unsupported telemetry stays unknown. User-recorded station status is not a NASA diagnosis.

## Backend integration

The Python client reads `GET /api/dashboard?missionId=demo-mission&droneId=drone-01` every 3 seconds with asynchronous Qt networking, a 10-second inactivity timeout, and no overlapping dashboard requests. The Backend tab preserves station telemetry, weather, power/battery inventories, source flags, observation timestamps and freshness labels. Images are downloaded from the actual returned image URL. Failed requests retain historical data with a disconnected warning.

Backend data is kept separate from NASA data. In particular, backend `demo-local-meters` coordinates are not assigned arbitrary Mars longitude/latitude, and demo records are never relabeled NASA observations. No backend code or API was changed. The frontend requires no upload token or CORS changes.

Optional frontend environment variables: `MARS_BACKEND_URL`, `MARS_MISSION_ID`, `MARS_DRONE_ID`.

Demo senders, from the backend folder:

```powershell
node simulator.mjs
node drone-simulator.mjs 'C:\path\to\your-photo.jpg'
```

Both senders mark data simulated. Supply a real PNG/JPEG; the sender's default tiny image fails Qt's PNG integrity check. Local photo import and the selected inbox folder remain supported separately from backend images.

## Persistence

NASA mission points, astronaut marker, stations and trail: `~/.mars_mission_control/mission_nasa.sqlite3`. The previous screenshot workspace remains untouched in `mission.sqlite3`. Its pixel markers are not assigned geographic positions. Projected scene coordinates span 1306 x 681 units, longitude -180..180, latitude 90..-90, independently of viewport zoom. Recorded route events retain source, geographic points, mobility assumptions and computed metrics.

## Verification

From the frontend folder:

```powershell
.\ui\.venv\Scripts\python.exe -m unittest test_planner test_nasa_map test_backend -v
.\ui\.venv\Scripts\python.exe ..\smoke_test.py
```

Backend checks: `node --test` in the backend folder. Tests include an unmodified real NASA MOLA TIFF fixture, geographic sampling, topography-dependent paths, missing-data barriers, dateline geometry, missing weather values, asynchronous refresh/recovery and mission UI persistence. Synthetic test grids are never used as production data.

## Primary sources

- NASA Trek configuration, including the MOLA DEM endpoint: https://trek.nasa.gov/mars/jpl/config/config.json
- NASA Trek WMTS documentation: https://trek.nasa.gov/tiles/apidoc/trekAPI.html?body=mars
- MOLA ImageServer metadata: https://trek.nasa.gov/mars/trekarcgis/rest/services/mola128_mola64_merge_90Nto90S_SimpleC_clon0/ImageServer?f=pjson
- NASA Curiosity REMS outreach feed: https://mars.nasa.gov/rss/api/?feed=weather&category=msl&feedtype=json
- NASA Perseverance MEDA outreach feed: https://mars.nasa.gov/rss/api/?feed=weather&category=mars2020&feedtype=json
- NASA RAD scope: https://science.nasa.gov/resource/radiation-measurements-on-mars/
- ExportImage parameter documentation: https://developers.arcgis.com/rest/services-reference/enterprise/export-image/
