# Mars Mission Control — Phase 1 (Python desktop prototype)

A native **PySide6 desktop application**, using the exact clean Mars map screenshot supplied by the user. **No HTML, CSS, JavaScript or web browser UI.** The screenshot is not modified or recolored; Qt places interactive layers above it.

## Run

```bash
cd mars_mission_control
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS / Linux:
# source .venv/bin/activate
pip install -r requirements.txt
python main.py
```

## Map and initial points

- Background: `assets/mars_map.png` (user's clean screenshot, 1306 × 681 px).
- B: **(170,270)** image pixels — center of the Arsia Mons feature the user circled in red in the reference screenshot.
- A: **(425,440)** image pixels — a *provisional, visually selected* landing location southeast of B. **No landing-site suitability verification** has been done.
- The screenshot is **not georeferenced**. These are only image pixel positions, **not** Mars latitudes/longitudes.

## Features

- Mouse wheel zoom, pan/drag and fit-to-screen.
- Toolbar: Pan / Inspect; Place A; Place B; Add Station; Move Drone; Add Track Point.
- Three colored **illustrative** route alternatives and route selection from the map or right panel.
- Pixel route lengths; a **hypothetical** travel time only when you manually specify a pixels-per-km scale and nominal travel speed. The route engine does **not** know real terrain, elevation, obstacles, or navigability.
- Transparent simulated storm with direction arrow; toggles and simulation parameters. Wind speed and duration are user-input demo values, **not** observations. The moving ellipse is for visualization only, with no physical forecast model.
- Simulated drone telemetry, ability to move its marker, and view a locally imported photo.
- Place stations and simulate diagnostic status changes (NORMAL / LOW_POWER / LINK_TIMEOUT / SENSOR_FAILURE); dotted links show illustrative station topology, not a live network.
- Record **manual** visited locations with timestamps; SQLite stores them, station markers, A/B, drone position, selected route events and status updates.
- Layer toggles, collapsible route and telemetry dock panels, history viewer.

## Data storage

The application stores its database at `~/.mars_mission_control/mission.sqlite3` so data persists across app restarts. Local photo files are opened for preview, not copied into the project/database.

## What is *not* implemented in Phase 1

- Real Mars Trek WMTS tile retrieval or map georeferencing.
- Mars MOLA DEM / elevation / slope checks or terrain-aware safe pathfinding.
- Actual rover/drone hardware connectivity, live images, sensor data, or reliable station-to-station networking.
- Physical storm movement, escape-path safety verification, or live Mars weather.
- Validated site suitability, travel distance in km, reliable arrival estimates.

**DO NOT use this prototype to make real mission-navigation or safety decisions.**

## Recommended Phase 2

Obtain an appropriately georeferenced Mars Trek/MOLA DEM raster and matching imagery; establish the map projection and Mars geographic coordinates; select a vehicle and constraints; then build an obstacle-constrained routing graph, multi-objective path finding and credible travel-time/risk models. The geographic alignment and ground-truth uncertainty must be validated before describing a route as safe.
