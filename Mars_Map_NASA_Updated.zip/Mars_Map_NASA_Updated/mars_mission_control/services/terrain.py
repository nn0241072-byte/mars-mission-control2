"""Quantitative NASA Trek MOLA DEM access and geographic raster geometry."""
from dataclasses import dataclass
import hashlib
import math
from pathlib import Path
import struct
import urllib.parse
import urllib.request

DEM_SERVICE='https://trek.nasa.gov/mars/trekarcgis/rest/services/mola128_mola64_merge_90Nto90S_SimpleC_clon0/ImageServer'
MARS_RADIUS_KM=3396.19


def distance_km(a,b):
    lon1,lat1=map(math.radians,a);lon2,lat2=map(math.radians,b)
    value=math.sin((lat2-lat1)/2)**2+math.cos(lat1)*math.cos(lat2)*math.sin((lon2-lon1)/2)**2
    return 2*MARS_RADIUS_KM*math.asin(math.sqrt(min(1,max(0,value))))


def read_float_tiff(data):
    """Decode the uncompressed, single-band float32 TIFF explicitly requested below."""
    endian='<' if data[:2]==b'II' else '>' if data[:2]==b'MM' else None
    if endian is None or struct.unpack_from(endian+'H',data,2)[0]!=42:
        raise ValueError('NASA returned an invalid elevation TIFF')
    offset=struct.unpack_from(endian+'I',data,4)[0]
    count=struct.unpack_from(endian+'H',data,offset)[0];tags={}
    for i in range(count):
        pos=offset+2+i*12;tag,kind,n=struct.unpack_from(endian+'HHI',data,pos)
        if kind not in (3,4):continue
        size=2 if kind==3 else 4
        start=pos+8 if n*size<=4 else struct.unpack_from(endian+'I',data,pos+8)[0]
        tags[tag]=struct.unpack_from(endian+('H' if kind==3 else 'I')*n,data,start)
    width=tags[256][0];height=tags[257][0]
    if tags[258]!=(32,) or tags[259]!=(1,) or tags.get(339)!=(3,) or tags.get(277,(1,))!=(1,):
        raise ValueError('Expected uncompressed float32 MOLA heights')
    values=[math.nan]*(width*height)
    if 324 in tags:
        tw=tags[322][0];th=tags[323][0];cols=math.ceil(width/tw)
        for tile,start in enumerate(tags[324]):
            tx=(tile%cols)*tw;ty=(tile//cols)*th
            for y in range(min(th,height-ty)):
                n=min(tw,width-tx)
                row=struct.unpack_from(endian+'f'*n,data,start+y*tw*4)
                values[(ty+y)*width+tx:(ty+y)*width+tx+n]=row
    else:
        rows=tags.get(278,(height,))[0]
        for strip,start in enumerate(tags[273]):
            y=strip*rows;n=min(rows,height-y)*width
            values[y*width:y*width+n]=struct.unpack_from(endian+'f'*n,data,start)
    return width,height,[v if math.isfinite(v) and -15000<v<30000 else math.nan for v in values]


@dataclass
class TerrainGrid:
    west:float
    south:float
    east:float
    north:float
    width:int
    height:int
    values:list
    source:str=DEM_SERVICE

    def lonlat(self,index):
        y,x=divmod(index,self.width)
        return (self.west+(x+.5)*(self.east-self.west)/self.width,
                self.north-(y+.5)*(self.north-self.south)/self.height)

    def index(self,point):
        lon,lat=point
        lon+=360*round(((self.west+self.east)/2-lon)/360)
        if not self.west<=lon<=self.east or not self.south<=lat<=self.north:return None
        x=min(self.width-1,int((lon-self.west)/(self.east-self.west)*self.width))
        y=min(self.height-1,int((self.north-lat)/(self.north-self.south)*self.height))
        if not 0<=x<self.width or not 0<=y<self.height:return None
        return y*self.width+x

    def sample(self,point):
        index=self.index(point)
        return self.values[index] if index is not None and math.isfinite(self.values[index]) else None

    @property
    def resolution_km(self):
        mid=self.height//2*self.width+self.width//2
        return max(.463,distance_km(self.lonlat(mid),self.lonlat(mid+1)),
                   distance_km(self.lonlat(mid),self.lonlat(mid+self.width)))


def fetch_piece(bounds,width,height,cache_dir):
    query=dict(bbox=','.join(f'{x:.9f}' for x in bounds),bboxSR=104905,imageSR=104905,
               size=f'{width},{height}',format='tiff',pixelType='F32',noData=-32768,
               interpolation='RSP_BilinearInterpolation',adjustAspectRatio='false',f='image',compression='None')
    url=DEM_SERVICE+'/exportImage?'+urllib.parse.urlencode(query)
    path=Path(cache_dir)/('mola-'+hashlib.sha256(url.encode()).hexdigest()+'.tif')
    if path.exists():data=path.read_bytes()
    else:
        with urllib.request.urlopen(url,timeout=25) as response:data=response.read(8*1024*1024)
        read_float_tiff(data)
        path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
    w,h,values=read_float_tiff(data)
    if (w,h)!=(width,height):raise ValueError('NASA returned an unexpected DEM extent')
    return values


def fetch_terrain(a,b,cache_dir,size=129):
    # Unwrap the longitude interval around A so antimeridian trips take the short way.
    lon2=a[0]+((b[0]-a[0]+180)%360-180)
    span_lon=abs(lon2-a[0]);span_lat=abs(b[1]-a[1])
    margin=max(.06,max(span_lon,span_lat)*.18)
    west=min(a[0],lon2)-margin;east=max(a[0],lon2)+margin
    south=max(-90,min(a[1],b[1])-margin);north=min(90,max(a[1],b[1])+margin)
    west=max(west,-360);east=min(east,360)
    if south>=north:raise ValueError('Polar extent unavailable')
    # Split at the antimeridian, preserving equal cell spacing in the merged grid.
    step=(east-west)/size
    chunks=[];start=0
    while start<size:
        center=west+(start+.5)*step
        shift=360*math.floor((center+180)/360)
        end=start+1
        while end<size and math.floor((west+(end+.5)*step+180)/360)*360==shift:end+=1
        bounds=(west+start*step-shift,south,west+end*step-shift,north)
        chunks.append((start,end,fetch_piece(bounds,end-start,size,cache_dir)))
        start=end
    values=[math.nan]*(size*size)
    for start,end,part in chunks:
        for row in range(size):values[row*size+start:row*size+end]=part[row*(end-start):(row+1)*(end-start)]
    grid=TerrainGrid(west,south,east,north,size,size,values)
    if grid.sample(a) is None or grid.sample(b) is None:raise ValueError('No elevation coverage at A or B')
    return grid
