"""Slope-aware A* routing over quantitative MOLA heights. No random paths."""
from dataclasses import dataclass
import heapq
import math
from services.terrain import distance_km


@dataclass(frozen=True)
class Mobility:
    name:str='Сансрын нисгэгч'
    speed_kmh:float=3.0
    mass_kg:float=150.0
    base_power_w:float=250.0
    efficiency:float=.25
    max_slope_deg:float=15.0


def edge_metrics(a,b,za,zb,profile):
    distance=distance_km(a,b)
    slope=math.degrees(math.atan2(abs(zb-za),max(.001,distance*1000)))
    hours=distance/profile.speed_kmh*(1+(slope/8)**2)
    energy=hours*profile.base_power_w+max(0,zb-za)*profile.mass_kg*3.71/(3600*profile.efficiency)
    return distance,slope,hours,energy


def astar(grid,a,b,profile,objective):
    start=grid.index(a);goal=grid.index(b)
    if start is None or goal is None:return None
    if start==goal:return [start]
    coords=[grid.lonlat(i) for i in range(len(grid.values))]
    queue=[(0,0,start)];costs={start:0};parent={}
    while queue:
        _,cost,node=heapq.heappop(queue)
        if cost>costs[node]:continue
        if node==goal:
            path=[node]
            while node!=start:node=parent[node];path.append(node)
            return path[::-1]
        y,x=divmod(node,grid.width)
        for dx,dy in ((1,0),(-1,0),(0,1),(0,-1),(1,1),(-1,-1),(1,-1),(-1,1)):
            xx=x+dx;yy=y+dy
            if not 0<=xx<grid.width or not 0<=yy<grid.height:continue
            nxt=yy*grid.width+xx
            z=grid.values[nxt]
            if not math.isfinite(z):continue
            if dx and dy and (not math.isfinite(grid.values[y*grid.width+xx]) or not math.isfinite(grid.values[yy*grid.width+x])):continue
            distance,slope,hours,_=edge_metrics(coords[node],coords[nxt],grid.values[node],z,profile)
            if slope>profile.max_slope_deg:continue
            step=hours if objective=='fastest' else hours*(1+12*(slope/5)**2)
            candidate=cost+step
            if candidate>=costs.get(nxt,math.inf):continue
            costs[nxt]=candidate;parent[nxt]=node
            heuristic=distance_km(coords[nxt],coords[goal])/profile.speed_kmh
            heapq.heappush(queue,(candidate+heuristic,candidate,nxt))
    return None


def plan_routes(grid,a,b,profile=Mobility()):
    if distance_km(a,b)<.001:return []
    result=[]
    for key,name,color in [('fastest','Хамгийн хурдан','#60e4cf'),('safest','Налуугийн эрсдэл багатай','#79baff')]:
        indices=astar(grid,a,b,profile,key)
        if indices is None:continue
        points=[a,b] if len(indices)==1 else [a]+[grid.lonlat(index) for index in indices]+[b]
        # Endpoints use their measured raster cells; connections are part of the metrics.
        heights=[grid.sample(a),grid.sample(b)] if len(indices)==1 else [grid.sample(a)]+[grid.values[index] for index in indices]+[grid.sample(b)]
        distance=hours=energy=ascent=0.;max_slope=0.
        for p,q,za,zb in zip(points,points[1:],heights,heights[1:]):
            d,s,t,e=edge_metrics(p,q,za,zb,profile)
            distance+=d;hours+=t;energy+=e;ascent+=max(0,zb-za);max_slope=max(max_slope,s)
        result.append(dict(key=key,name=name,color=color,lonlat=points,distance_km=distance,
                           hours=hours,energy_wh=energy,ascent_m=ascent,max_slope_deg=max_slope,
                           resolution_km=grid.resolution_km,radiation_usv=None,
                           risk='Өндөр' if max_slope>=10 else 'Дунд' if max_slope>=5 else 'Бага',
                           source=grid.source,profile=profile.__dict__,effort=1))
    return result
