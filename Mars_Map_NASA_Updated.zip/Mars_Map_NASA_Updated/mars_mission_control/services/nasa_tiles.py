"""NASA Trek WMTS metadata and asynchronous visible-tile rendering for Qt."""
import math
import time
import xml.etree.ElementTree as ET
from PySide6.QtCore import QObject, QStandardPaths, QTimer, QUrl, Signal, Qt
from PySide6.QtGui import QPixmap
from PySide6.QtNetwork import QNetworkAccessManager, QNetworkDiskCache, QNetworkReply, QNetworkRequest

LAYER='Mars_Viking_MDIM21_ClrMosaic_global_232m'
ENDPOINT=f'https://trek.nasa.gov/tiles/Mars/EQ/{LAYER}/1.0.0'
CAPABILITIES=ENDPOINT+'/WMTSCapabilities.xml'
NS={'w':'http://www.opengis.net/wmts/1.0','o':'http://www.opengis.net/ows/1.1'}


def parse_capabilities(content):
    root=ET.fromstring(content)
    layer=root.find('.//w:Layer',NS)
    template=layer.find('w:ResourceURL',NS).attrib['template']
    style=layer.find('w:Style/o:Identifier',NS).text
    matrix_set=root.find('.//w:Contents/w:TileMatrixSet',NS)
    identifier=matrix_set.find('o:Identifier',NS).text
    matrices=[]
    for matrix in matrix_set.findall('w:TileMatrix',NS):
        def number(name):return int(float(matrix.find('w:'+name,NS).text))
        matrices.append({'id':matrix.find('o:Identifier',NS).text,
                         'cols':number('MatrixWidth'),'rows':number('MatrixHeight'),
                         'width':number('TileWidth'),'height':number('TileHeight')})
    if not matrices:raise ValueError('NASA WMTS returned no tile matrices')
    return template.replace('{Style}',style).replace('{TileMatrixSet}',identifier),matrices


class NasaTiles(QObject):
    status_changed=Signal(str)

    def __init__(self,view,capabilities_url=None,base_z=-100,opacity=1):
        super().__init__(view)
        self.view=view
        self.capabilities_url=capabilities_url or CAPABILITIES
        self.source_name='Odyssey THEMIS' if 'THEMIS' in self.capabilities_url else 'Viking global mosaic'
        self.base_z=base_z;self.opacity=opacity
        self.network=QNetworkAccessManager(self)
        cache=QNetworkDiskCache(self.network)
        cache.setCacheDirectory(QStandardPaths.writableLocation(QStandardPaths.StandardLocation.CacheLocation)+'/nasa-wmts')
        cache.setMaximumCacheSize(100*1024*1024)
        self.network.setCache(cache)
        self.template=None;self.matrices=[];self.items={};self.pending={};self.failed={}
        self.stopped=False;self.metadata_pending=False;self.retry_at=0
        self.timer=QTimer(self);self.timer.setInterval(180);self.timer.timeout.connect(self.update_visible)
        self.timer.start()
        QTimer.singleShot(0,self.load_metadata)

    def request(self,url):
        request=QNetworkRequest(QUrl(url));request.setTransferTimeout(15000)
        request.setRawHeader(b'User-Agent',b'MarsMissionControl/1.0 (NASA Trek WMTS client)')
        return self.network.get(request)

    def load_metadata(self):
        if self.stopped or self.metadata_pending:return
        self.metadata_pending=True
        self.status_changed.emit('NASA Trek: loading map service…')
        reply=self.request(self.capabilities_url)
        self.metadata_reply=reply
        reply.finished.connect(lambda:self.metadata_finished(reply))

    def metadata_finished(self,reply):
        self.metadata_pending=False
        try:
            if self.stopped:return
            if reply.error()!=QNetworkReply.NetworkError.NoError:raise ValueError(reply.errorString())
            self.template,self.matrices=parse_capabilities(bytes(reply.readAll()))
            self.update_visible()
        except (ValueError,ET.ParseError,AttributeError,KeyError) as error:
            self.retry_at=time.monotonic()+15
            self.status_changed.emit('NASA Trek: disconnected • retrying ('+str(error)+')')
        finally:reply.deleteLater()

    def visible_keys(self):
        rect=self.view.mapToScene(self.view.viewport().rect()).boundingRect().intersected(self.view.sceneRect())
        if rect.isEmpty():return set()
        scale=self.view.transform().m11()
        desired=max(0,math.ceil(math.log2(max(1,self.view.map_width*scale/512))))
        level=min(desired,len(self.matrices)-1)
        matrix=self.matrices[level]
        dx=self.view.map_width/matrix['cols'];dy=self.view.map_height/matrix['rows']
        return {(level,row,col)
                for row in range(max(0,int(rect.top()/dy)),min(matrix['rows']-1,int(rect.bottom()/dy))+1)
                for col in range(max(0,int(rect.left()/dx)),min(matrix['cols']-1,int(rect.right()/dx))+1)}

    def update_visible(self):
        if self.stopped:return
        if self.template is None:
            if time.monotonic()>=self.retry_at:self.load_metadata()
            return
        keys=self.visible_keys()
        # A low-resolution global base remains underneath detail tiles while zooming.
        keys.update({(0,0,0),(0,0,1)})
        for key,reply in list(self.pending.items()):
            if key not in keys:
                reply.setProperty('obsolete',True);reply.abort()
        for key in sorted(keys):
            if len(self.pending)>=6:break
            if key in self.items or key in self.pending or self.failed.get(key,0)>time.monotonic():continue
            level,row,col=key
            url=self.template.replace('{TileMatrix}',self.matrices[level]['id']).replace('{TileRow}',str(row)).replace('{TileCol}',str(col))
            reply=self.request(url);self.pending[key]=reply
            reply.finished.connect(lambda k=key,r=reply:self.tile_finished(k,r))
        if len(self.items)>192:
            for key in list(self.items):
                if key not in keys:
                    self.view.scene_.removeItem(self.items.pop(key))
                    if len(self.items)<=192:break

    def tile_finished(self,key,reply):
        self.pending.pop(key,None)
        try:
            if self.stopped or reply.property('obsolete'):return
            pix=QPixmap()
            if reply.error()!=QNetworkReply.NetworkError.NoError or not pix.loadFromData(bytes(reply.readAll())):
                self.failed[key]=time.monotonic()+15
                self.status_changed.emit('NASA Trek: tile unavailable • cached areas retained • retrying')
                return
            level,row,col=key;matrix=self.matrices[level]
            from PySide6.QtGui import QTransform
            item=self.view.scene_.addPixmap(pix)
            item.setTransformationMode(Qt.TransformationMode.SmoothTransformation)
            dx=self.view.map_width/matrix['cols'];dy=self.view.map_height/matrix['rows']
            item.setTransform(QTransform.fromScale(dx/pix.width(),dy/pix.height()))
            item.setPos(col*dx,row*dy);item.setZValue(self.base_z+level);item.setOpacity(self.opacity)
            self.items[key]=item;self.failed.pop(key,None)
            self.status_changed.emit(f'NASA Trek: connected • {self.source_name} • NASA/JPL')
        finally:reply.deleteLater()

    def stop(self):
        self.stopped=True;self.timer.stop()
        if self.metadata_pending:self.metadata_reply.abort()
        for reply in list(self.pending.values()):reply.abort()
