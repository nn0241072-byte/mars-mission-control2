"""Mission station terrain samples; no synthetic weather or hazard percentages."""
def sample_station(position,terrain_grid=None):
    value=terrain_grid.sample(position) if terrain_grid is not None else None
    return {'elevation_m':value,'source':'NASA MOLA' if value is not None else None}
