"""Categorical maps from numeric NASA raster values; missing pixels stay transparent."""
import bisect
import math
from PySide6.QtGui import QColor,QImage
from services.terrain import fetch_piece,TerrainGrid

ELEVATION_BREAKS=(-4000,-2000,0,2000,6000,12000)
ELEVATION_COLORS=('#46a4d0','#7ac7ce','#68bb78','#f0df7b','#f5a064','#ef6356','#cf365b')
ELEVATION_LABELS=('−8201 … −4000','−4000 … −2000','−2000 … 0','0 … 2000','2000 … 6000','6000 … 12000','12000 … 22000')


def classified_image(grid,breaks=ELEVATION_BREAKS,colors=ELEVATION_COLORS):
    palette=[QColor(value).rgba() for value in colors]
    image=QImage(grid.width,grid.height,QImage.Format.Format_ARGB32)
    image.fill(0)
    for index,value in enumerate(grid.values):
        if math.isfinite(value):image.setPixel(index%grid.width,index//grid.width,palette[bisect.bisect_right(breaks,value)])
    return image


def fetch_global_elevation(cache_dir):
    width,height=1440,720
    values=fetch_piece((-180,-90,180,90),width,height,cache_dir)
    grid=TerrainGrid(-180,-90,180,90,width,height,values)
    return grid,classified_image(grid)
