"""Repeatable independent random streams for map positions, across restarts."""
import random


def position_key(point):
    return f'{float(point[0]):.6f},{float(point[1]):.6f}'


def spatial_rng(namespace, *points):
    # String seeds avoid Python hash randomization and normalize int/float inputs.
    return random.Random(namespace + ':' + ':'.join(position_key(p) for p in points))
