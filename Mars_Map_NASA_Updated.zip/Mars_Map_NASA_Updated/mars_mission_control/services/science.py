"""Background NASA data tasks and point weather; absent readings stay absent."""
import json
import math
import urllib.request
import threading
from PySide6.QtCore import QObject,QRunnable,Signal

REMS_URL='https://mars.nasa.gov/rss/api/?feed=weather&category=msl&feedtype=json'
MEDA_URL='https://mars.nasa.gov/rss/api/?feed=weather&category=mars2020&feedtype=json'


class JobSignals(QObject):
    finished=Signal(int,object)
    failed=Signal(int,str)


class Job(QRunnable):
    def __init__(self,token,function):
        super().__init__();self.token=token;self.function=function;self.signals=JobSignals()
        self.cancelled=threading.Event()

    def cancel(self):
        self.cancelled.set()

    def run(self):
        if self.cancelled.is_set():return
        try:result=self.function();error=None
        except Exception as problem:result=None;error=str(problem)
        if self.cancelled.is_set():return
        try:
            if error is None:self.signals.finished.emit(self.token,result)
            else:self.signals.failed.emit(self.token,error)
        except RuntimeError:
            # QApplication can destroy QObject signal sources during shutdown.
            return


def number(value):
    try:
        result=float(value)
        return result if math.isfinite(result) else None
    except (ValueError,TypeError):return None


def wind_color(speed):
    if speed is None:return '#8996a9'
    return '#f05264' if speed>=55 else '#ff9c55' if speed>=30 else '#f1ce6b' if speed>=15 else '#59d9b6'


def parse_weather(data,name,position,url):
    records=data.get('soles',data.get('sols',[]))
    if not records:return None
    row=max(records,key=lambda r:r.get('terrestrial_date',''))
    return dict(name=name,position=position,date=row.get('terrestrial_date','—'),sol=row.get('sol'),
                min_c=number(row.get('min_temp')),max_c=number(row.get('max_temp')),
                ground_min_c=number(row.get('min_gts_temp')),ground_max_c=number(row.get('max_gts_temp')),
                wind_mps=number(row.get('wind_speed')),wind_deg=number(row.get('wind_direction')),
                pressure_pa=number(row.get('pressure')),source=url,scope='local',archived=True)


def fetch_weather():
    stations=[]
    for url,name,position in [(REMS_URL,'Curiosity · REMS',(137.44,-4.59)),(MEDA_URL,'Perseverance · MEDA',(77.45,18.44))]:
        with urllib.request.urlopen(url,timeout=20) as response:data=json.load(response)
        record=parse_weather(data,name,position,url)
        if record:stations.append(record)
    return stations
