"""Read-only native Qt client for the Mars backend; no worker or UI blocking I/O."""
import json
import os
from urllib.parse import urlencode

from PySide6.QtCore import QObject, QTimer, QUrl, Signal
from PySide6.QtNetwork import QNetworkAccessManager, QNetworkReply, QNetworkRequest


class BackendClient(QObject):
    dashboard_received = Signal(dict)
    failed = Signal(str)
    image_received = Signal(str, bytes)
    image_failed = Signal(str, str)

    def __init__(self, parent=None, base_url=None, interval_ms=3000):
        super().__init__(parent)
        self.base_url = QUrl(base_url or os.getenv('MARS_BACKEND_URL', 'http://127.0.0.1:8787'))
        if (self.base_url.scheme() not in ('http', 'https') or not self.base_url.host()
                or self.base_url.userInfo()):
            raise ValueError('MARS_BACKEND_URL must be an HTTP(S) URL without credentials')
        self.mission_id = os.getenv('MARS_MISSION_ID', 'demo-mission')
        self.drone_id = os.getenv('MARS_DRONE_ID', 'drone-01')
        self.network = QNetworkAccessManager(self)
        self.timer = QTimer(self)
        self.timer.setInterval(interval_ms)
        self.timer.timeout.connect(self.refresh)
        self.pending = None
        self.image_pending = None
        self.stopped = True

    def start(self):
        self.stopped = False
        self.timer.start()
        self.refresh()

    def stop(self):
        self.stopped = True
        self.timer.stop()
        for reply in (self.pending, self.image_pending):
            if reply is not None:
                reply.abort()

    def _get(self, url):
        request = QNetworkRequest(url)
        request.setTransferTimeout(10000)
        request.setAttribute(QNetworkRequest.Attribute.CacheLoadControlAttribute,
                             QNetworkRequest.CacheLoadControl.AlwaysNetwork)
        return self.network.get(request)

    def refresh(self):
        if self.stopped or self.pending is not None:
            return
        query = urlencode({'missionId': self.mission_id, 'droneId': self.drone_id})
        reply = self._get(self.base_url.resolved(QUrl('/api/dashboard?' + query)))
        self.pending = reply
        reply.finished.connect(lambda: self._dashboard_finished(reply))

    def _dashboard_finished(self, reply):
        self.pending = None
        try:
            if self.stopped:
                return
            if reply.error() != QNetworkReply.NetworkError.NoError:
                raise ValueError(reply.errorString())
            data = json.loads(bytes(reply.readAll()))
            if (not isinstance(data, dict) or not isinstance(data.get('posts'), list)
                    or not all(isinstance(post, dict) for post in data['posts'])
                    or not isinstance(data.get('layers'), dict)
                    or not isinstance(data.get('latestDroneImage'), (dict, type(None)))):
                raise ValueError('Invalid dashboard response')
            for post in data['posts']:
                layers=post.get('layers',{})
                power=post.get('power',{})
                if (not isinstance(layers, dict) or not isinstance(power, dict)
                        or not all(isinstance(reading, dict) for reading in layers.values())):
                    raise ValueError('Invalid station response')
            image=data.get('latestDroneImage')
            if image and not isinstance(image.get('imageUrl'), str):
                raise ValueError('Invalid drone image response')
            self.dashboard_received.emit(data)
        except (ValueError, TypeError) as error:
            self.failed.emit(str(error))
        finally:
            reply.deleteLater()

    def fetch_image(self, reference):
        if self.stopped or self.image_pending is not None:
            return
        url = self.base_url.resolved(QUrl(reference))
        if url.scheme() not in ('http', 'https') or url.userInfo():
            self.image_failed.emit(reference, 'Invalid HTTP(S) image URL')
            return
        reply = self._get(url)
        self.image_pending = reply
        reply.finished.connect(lambda: self._image_finished(reply, reference))

    def _image_finished(self, reply, reference):
        self.image_pending = None
        try:
            if self.stopped:
                return
            if reply.error() != QNetworkReply.NetworkError.NoError:
                self.image_failed.emit(reference, reply.errorString())
            else:
                self.image_received.emit(reference, bytes(reply.readAll()))
        finally:
            reply.deleteLater()
