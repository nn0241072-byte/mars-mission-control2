import math
import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
import unittest
from unittest.mock import patch
from PySide6.QtWidgets import QApplication
from services.terrain import TerrainGrid
from services.thematic import classified_image,ELEVATION_COLORS
from ui.map_view import MarsView
from services.nasa_tiles import NasaTiles


class ThematicTest(unittest.TestCase):
    def test_elevation_classes_and_missing_coverage(self):
        values=[-8000,-4000,-2000,0,2000,6000,12000,math.nan]
        grid=TerrainGrid(-180,-90,180,90,8,1,values)
        image=classified_image(grid)
        self.assertEqual([image.pixelColor(i,0).name() for i in range(7)],list(ELEVATION_COLORS))
        self.assertEqual(image.pixelColor(7,0).alpha(),0)

    def test_region_map_survives_mission_overlay_refresh(self):
        app=QApplication.instance() or QApplication([])
        with patch.object(NasaTiles,'load_metadata',lambda self:None):
            view=MarsView()
            image=classified_image(TerrainGrid(-180,-90,180,90,2,1,[-5000,3000]))
            view.set_thematic_image(image)
            item=view.thematic_item
            for _ in range(3):view.render_overlay()
            self.assertIs(item.scene(),view.scene_)
            self.assertLess(item.zValue(),0)
            self.assertEqual(item.boundingRect().width()*item.transform().m11(),view.map_width)
            view.tiles.stop();view.close()


if __name__=='__main__':unittest.main()
