"""Run from the frontend root: python -m unittest test_backend -v."""
import copy
import json
import os
import tempfile
import threading
import time
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from unittest.mock import patch

os.environ['QT_QPA_PLATFORM']='offscreen'
from PySide6.QtCore import QSettings, QTimer, Qt, QBuffer, QIODevice
from PySide6.QtGui import QImage, QColor
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication
from ui import main_window


PHOTO=b''
STAMP='2026-11-15T06:00:00.000Z'
DATA={
    'serverTime':STAMP,'missionId':'demo-mission','coordinateFrame':'demo-local-meters',
    'posts':[{'postId':'urtuu-01','simulated':True,'observedAt':STAMP,
              'position':{'frame':'demo-local-meters','xM':1200,'yM':400},
              'layers':{'weather':{'status':'stale','observedAt':STAMP,'airTemperatureC':-45,
                                   'windSpeedMps':8,'pressurePa':650,'windDirectionDeg':120},
                        'thermal':{'status':'unknown'}},
              'power':{'status':'stale','solarOutputW':400,'stationLoadW':100,
                       'batteries':[{'id':'pack-01','stateOfChargePct':90,'capacityWh':2000,
                                     'status':'available','compatibility':'demo-rover-pack-v1'}]}}],
    'layers':{'weather':[],'optical':[],'thermal':[],'radiation':[]},
    'latestDroneImage':{'imageId':'one','imageUrl':'/photos/one.png','simulated':True,
                        'capturedAt':STAMP,'status':'stale','caption':'Test capture'},
}


class Handler(BaseHTTPRequestHandler):
    def log_message(self,*args):pass

    def do_GET(self):
        self.server.paths.append(self.path)
        if self.path.startswith('/api/dashboard?'):
            time.sleep(self.server.delay)
            code=503 if self.server.mode=='error' else 200
            payload=b'not json' if self.server.mode=='malformed' else json.dumps(self.server.data).encode()
            content_type='application/json'
        else:
            code=200;payload=b'invalid image' if self.server.invalid_image else PHOTO;content_type='image/png'
        self.send_response(code)
        self.send_header('Content-Type',content_type)
        self.send_header('Content-Length',str(len(payload)))
        self.end_headers()
        try:self.wfile.write(payload)
        except OSError:pass  # The client intentionally aborts its request on close.


class BackendIntegrationTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app=QApplication.instance() or QApplication([])
        global PHOTO
        image=QImage(32,20,QImage.Format.Format_RGB32);image.fill(QColor('orange'))
        buffer=QBuffer();buffer.open(QIODevice.OpenModeFlag.WriteOnly);image.save(buffer,'PNG')
        PHOTO=bytes(buffer.data())

    def wait_for(self,predicate,timeout=4000):
        deadline=time.monotonic()+timeout/1000
        while not predicate() and time.monotonic()<deadline:
            QTest.qWait(20)
        self.assertTrue(predicate())

    def test_network_ui_recovery_and_preservation(self):
        server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
        server.paths=[];server.delay=.25;server.mode='ok';server.data=copy.deepcopy(DATA);server.invalid_image=False
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        try:
            with tempfile.TemporaryDirectory() as tmp, patch.dict(os.environ,{
                    'MARS_BACKEND_URL':f'http://127.0.0.1:{server.server_port}'}), patch.object(main_window,'DATA_DIR',Path(tmp)):
                QSettings.setPath(QSettings.Format.NativeFormat,QSettings.Scope.UserScope,tmp)
                window=main_window.MainWindow()
                try:
                    for widget in (window.backend_summary,window.backend_photo_caption):
                        self.assertEqual(widget.textFormat(),Qt.TextFormat.PlainText)
                    original=(window.map.a,window.map.b,window.selected_route,copy.deepcopy(window.map.stations))
                    ticks=[];timer=QTimer();timer.timeout.connect(lambda:ticks.append(1));timer.start(10)
                    self.wait_for(lambda:window.backend_pixmap is not None)
                    self.assertGreater(len(ticks),5)  # UI event loop ran during slow HTTP response.
                    self.assertTrue(window.backend_connected)
                    text=window.backend_reports.toPlainText()
                    for expected in ('urtuu-01','SIMULATED','stale','unknown','-45','pack-01','90'):
                        self.assertIn(expected,text)
                    self.assertIn('Captured:',window.backend_photo_caption.text())
                    self.assertIn('-45',window.backend_weather.text())
                    self.assertEqual(original,(window.map.a,window.map.b,window.selected_route,window.map.stations))
                    self.assertIn('missionId=demo-mission&droneId=drone-01',server.paths[0])
                    self.assertIn('/photos/one.png',server.paths)
                    self.assertEqual(window.backend.timer.interval(),3000)
                    count=len(server.paths)
                    self.wait_for(lambda:len(server.paths)>count,3500)  # Automatic refresh.
                    self.wait_for(lambda:window.backend.pending is None)
                    server.invalid_image=True;window.backend_pixmap=None
                    window.backend.refresh()
                    self.wait_for(lambda:'unavailable' in window.backend_photo.text())
                    self.assertTrue(window.backend_connected)
                    server.invalid_image=False;window.backend.refresh()
                    self.wait_for(lambda:window.backend_pixmap is not None)
                    server.mode='error';window.backend.refresh()
                    self.wait_for(lambda:not window.backend_connected)
                    self.assertIn('cached snapshot',window.backend_summary.text())
                    self.assertIsNotNone(window.backend_pixmap)
                    server.mode='malformed';window.backend.refresh()
                    self.wait_for(lambda:window.backend.pending is None)
                    self.assertFalse(window.backend_connected)
                    server.mode='ok';server.data['latestDroneImage']=None
                    server.data['posts'][0]['simulated']=False
                    window.backend.refresh()
                    self.wait_for(lambda:window.backend_connected)
                    self.assertIsNone(window.backend_pixmap)
                    self.assertEqual(window.backend_photo.text(),'Waiting for drone photo')
                    self.assertIn('NON-SIMULATED',window.backend_reports.toPlainText())
                    server.data['posts']=[];window.backend.refresh()
                    self.wait_for(lambda:window.backend.pending is None)
                    self.assertIn('Waiting for station telemetry',window.backend_reports.toPlainText())
                    server.delay=.5;window.backend.refresh()
                    window.backend.refresh()  # No overlapping dashboard requests.
                    timer.stop()
                finally:
                    window.close()
                    QTest.qWait(600)
                self.assertFalse(window.backend.timer.isActive())
                self.assertTrue(window.backend.stopped)
                self.assertTrue(all(job.cancelled.is_set() for job in window.science_jobs.values()))
        finally:
            server.shutdown();server.server_close();thread.join()


if __name__=='__main__':unittest.main()
