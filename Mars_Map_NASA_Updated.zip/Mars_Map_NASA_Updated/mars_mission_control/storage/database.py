"""SQLite persistence for mission markers, selected routes and breadcrumb history."""
import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path


def utc_now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class MissionDB:
    def __init__(self, db_path):
        self.conn = sqlite3.connect(str(Path(db_path)))
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.executescript("""
          CREATE TABLE IF NOT EXISTS markers (
            id TEXT PRIMARY KEY, kind TEXT NOT NULL, x REAL NOT NULL,
            y REAL NOT NULL, status TEXT NOT NULL DEFAULT 'NORMAL',
            created_at TEXT NOT NULL
          );
          CREATE TABLE IF NOT EXISTS events (
            id INTEGER PRIMARY KEY AUTOINCREMENT, time TEXT NOT NULL,
            event TEXT NOT NULL, payload TEXT NOT NULL
          );
          CREATE TABLE IF NOT EXISTS trail (
            id INTEGER PRIMARY KEY AUTOINCREMENT, time TEXT NOT NULL,
            x REAL NOT NULL, y REAL NOT NULL
          );
        """)
        columns={row[1] for row in self.conn.execute('PRAGMA table_info(markers)')}
        if 'reading' not in columns:
            self.conn.execute("ALTER TABLE markers ADD COLUMN reading TEXT NOT NULL DEFAULT '{}'")
        self.conn.commit()

    def save_station_reading(self, marker_id, reading):
        self.conn.execute('UPDATE markers SET reading=? WHERE id=?',
                          (json.dumps(reading,ensure_ascii=False),marker_id))
        self.conn.commit()

    def delete_marker(self, marker_id):
        self.conn.execute('DELETE FROM markers WHERE id=?',(marker_id,))
        self.conn.commit()

    def rename_marker(self, old, new):
        self.conn.execute('UPDATE markers SET id=? WHERE id=?',(new,old))
        self.conn.commit()

    def upsert_marker(self, id, kind, x, y, status='NORMAL'):
        self.conn.execute("""INSERT INTO markers (id,kind,x,y,status,created_at)
          VALUES (?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET
          kind=excluded.kind, x=excluded.x, y=excluded.y, status=excluded.status""",
          (id,kind,float(x),float(y),status,utc_now()))
        self.conn.commit()

    def markers(self):
        rows=self.conn.execute("SELECT id,kind,x,y,status,reading FROM markers ORDER BY id").fetchall()
        markers=[dict(zip(('id','kind','x','y','status','reading'),row)) for row in rows]
        for marker in markers:marker['reading']=json.loads(marker['reading'])
        return markers

    def add_event(self, event, **data):
        self.conn.execute("INSERT INTO events(time,event,payload) VALUES (?,?,?)",
                          (utc_now(),event,json.dumps(data,ensure_ascii=False)))
        self.conn.commit()

    def events(self, limit=60):
        return self.conn.execute("SELECT time,event,payload FROM events ORDER BY id DESC LIMIT ?",(limit,)).fetchall()

    def add_trail(self,x,y):
        self.conn.execute("INSERT INTO trail(time,x,y) VALUES (?,?,?)",(utc_now(),float(x),float(y)))
        self.conn.commit()

    def trail(self):
        return self.conn.execute("SELECT x,y,time FROM trail ORDER BY id").fetchall()

    def clear_trail(self):
        self.conn.execute("DELETE FROM trail")
        self.conn.commit()

    def close(self):
        self.conn.close()
