"""Deterministic local HTTP tests of NASA WMTS geometry, loading and retries."""
import os
os.environ['QT_QPA_PLATFORM']='offscreen'
import threading
import time
import unittest
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from unittest.mock import patch
from PySide6.QtCore import QBuffer,QIODevice
from PySide6.QtGui import QColor,QImage
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication
from services import nasa_tiles
from ui.map_view import MarsView
from services.terrain import TerrainGrid
from services.planner import plan_routes


def capabilities(base):
    matrices=''.join(f'<TileMatrix><o:Identifier>{z}</o:Identifier><TileWidth>256</TileWidth><TileHeight>256</TileHeight><MatrixWidth>{2**(z+1)}.0</MatrixWidth><MatrixHeight>{2**z}.0</MatrixHeight></TileMatrix>' for z in range(4))
    return f'''<Capabilities xmlns="http://www.opengis.net/wmts/1.0" xmlns:o="http://www.opengis.net/ows/1.1"><Contents>
    <Layer><Style><o:Identifier>default</o:Identifier></Style><ResourceURL template="{base}/{{Style}}/{{TileMatrixSet}}/{{TileMatrix}}/{{TileRow}}/{{TileCol}}.jpg"/></Layer>
    <TileMatrixSet><o:Identifier>default028mm</o:Identifier>{matrices}</TileMatrixSet></Contents></Capabilities>'''.encode()


class Handler(BaseHTTPRequestHandler):
    def log_message(self,*args):pass
    def do_GET(self):
        self.server.paths.append(self.path)
        code=200
        if self.path=='/capabilities':payload=capabilities(self.server.base)
        elif self.server.fail:code=503;payload=b'unavailable'
        else:payload=self.server.image
        self.send_response(code);self.end_headers()
        try:self.wfile.write(payload)
        except OSError:pass


class NasaMapTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.app=QApplication.instance() or QApplication([])

    def wait_for(self,predicate):
        end=time.monotonic()+5
        while not predicate() and time.monotonic()<end:QTest.qWait(20)
        self.assertTrue(predicate())

    def test_wmts_pan_zoom_retry_and_coordinates(self):
        server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
        server.base=f'http://127.0.0.1:{server.server_port}'
        image=QImage(256,256,QImage.Format.Format_RGB32);image.fill(QColor('orange'))
        buffer=QBuffer();buffer.open(QIODevice.OpenModeFlag.WriteOnly);image.save(buffer,'JPG')
        server.image=bytes(buffer.data());server.paths=[];server.fail=True
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        try:
            with patch.object(nasa_tiles,'CAPABILITIES',server.base+'/capabilities'):
                view=MarsView('nonexistent-screenshot.png')
                try:
                    view.resize(900,600);view.show();view.fit_map()
                    view.a=view.from_lonlat(-8.789,-8.789)
                    view.b=view.from_lonlat(-120.09,-8.35)
                    for lon,lat in [(-180,90),(180,-90),(0,0),(-120.09,-8.35)]:
                        actual=view.lonlat(*view.from_lonlat(lon,lat))
                        self.assertAlmostEqual(lon,actual[0]);self.assertAlmostEqual(lat,actual[1])
                    self.wait_for(lambda:bool(view.tiles.failed))
                    self.assertFalse(view.tiles.items)
                    server.fail=False;view.tiles.failed.clear();view.tiles.update_visible()
                    self.wait_for(lambda:len(view.tiles.items)>=2)
                    original=(view.a,view.b)
                    grid=TerrainGrid(-180,-90,180,90,33,17,[0.]*(33*17))
                    view.routes=plan_routes(grid,view.lonlat(*view.a),view.lonlat(*view.b))
                    for route in view.routes:route['points']=[view.from_lonlat(*p) for p in route['lonlat']]
                    view.render_overlay()
                    self.assertEqual(2,len([item for item in view.overlay_items if hasattr(item,'route')]))
                    for _ in range(10):view.render_overlay()
                    self.assertTrue(all(item.scene() is view.scene_ for item in view.tiles.items.values()))
                    view.scale(8,8);view.centerOn(*view.a);view.tiles.update_visible()
                    self.wait_for(lambda:any(key[0]>=2 for key in view.tiles.items))
                    self.assertEqual(original,(view.a,view.b))
                    self.assertLessEqual(len(view.tiles.pending),6)
                    self.assertTrue(any('/default/default028mm/' in path for path in server.paths))
                finally:
                    view.tiles.stop();view.close();QTest.qWait(100)
                self.assertFalse(view.tiles.timer.isActive())
        finally:
            server.shutdown();server.server_close();thread.join()


if __name__=='__main__':unittest.main()
