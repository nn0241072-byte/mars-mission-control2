"""Interactive NASA Trek WMTS map with native Qt mission overlays."""
import math
from PySide6.QtCore import Qt, QPointF, QRectF, Signal
from PySide6.QtGui import QColor, QBrush, QPen, QPainter, QPainterPath, QFont, QRadialGradient, QPixmap,QTransform
from PySide6.QtWidgets import QGraphicsView, QGraphicsScene, QGraphicsPathItem, QGraphicsEllipseItem, QGraphicsItem
from services.science import wind_color
from services.nasa_tiles import NasaTiles


def color(hex): return QColor(hex)


def temperature_color(value):
    """Fixed Celsius scale for daily maximum observations; not image brightness."""
    stops=[(-100,'#4269dd'),(-60,'#40c8df'),(-20,'#f2d36c'),(30,'#ed6254')]
    value=max(-100,min(30,value))
    for (lo,left),(hi,right) in zip(stops,stops[1:]):
        if value<=hi:
            t=(value-lo)/(hi-lo);a=QColor(left);b=QColor(right)
            return QColor(round(a.red()+(b.red()-a.red())*t),round(a.green()+(b.green()-a.green())*t),round(a.blue()+(b.blue()-a.blue())*t))
    return QColor(stops[-1][1])


class MarkerItem(QGraphicsEllipseItem):
    def __init__(self, x, y, radius, name, callback):
        super().__init__(-radius,-radius,radius*2,radius*2)
        self.setPos(x,y)
        self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIgnoresTransformations)
        self.name=name
        self.callback=callback
        self.setCursor(Qt.CursorShape.PointingHandCursor)

    def mousePressEvent(self,event):
        if event.button()==Qt.MouseButton.LeftButton:
            self.callback(self.name)
            event.accept()
        else:super().mousePressEvent(event)


class RouteItem(QGraphicsPathItem):
    def __init__(self, path, route, on_click, highlighted=False):
        super().__init__(path)
        self.route=route
        self.on_click=on_click
        self.setZValue(2)
        self.setAcceptHoverEvents(True)
        stroke=color(route['color']);stroke.setAlpha(255 if highlighted else 65)
        pen=QPen(stroke,5 if highlighted else 2,Qt.PenStyle.SolidLine)
        pen.setCosmetic(True)
        self.setPen(pen)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setToolTip(f"{route['name']} • {route.get('distance_km',0):.2f} км")

    def mousePressEvent(self,event):
        if event.button()==Qt.MouseButton.LeftButton:
            self.on_click(self.route['key'])
            event.accept()
        else: super().mousePressEvent(event)


class AstronautItem(QGraphicsPathItem):
    def __init__(self,x,y,callback):
        path=QPainterPath();path.addEllipse(-7,-17,14,14)
        path.addRoundedRect(QRectF(-6,-1,12,14),3,3)
        path.moveTo(-6,3);path.lineTo(-12,10);path.moveTo(6,3);path.lineTo(12,10)
        path.moveTo(-3,13);path.lineTo(-5,22);path.moveTo(3,13);path.lineTo(5,22)
        super().__init__(path);self.setPos(x,y)
        self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIgnoresTransformations)
        self.setPen(QPen(QColor('#f1fafb'),2));self.setBrush(QBrush(QColor('#213e52')))
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.name='ASTRONAUT-01';self.callback=callback

    def mousePressEvent(self,event):
        if event.button()==Qt.MouseButton.LeftButton:self.callback(self.name);event.accept()
        else:super().mousePressEvent(event)


class MarsView(QGraphicsView):
    map_clicked=Signal(float,float)
    route_clicked=Signal(str)
    marker_clicked=Signal(str)
    cursor_changed=Signal(float,float)

    def __init__(self,image_path=None,parent=None):
        super().__init__(parent)
        self.scene_=QGraphicsScene(self)
        self.setScene(self.scene_)
        # Stable projected scene coordinates, independent of downloaded tile resolution.
        # image_path is accepted for callers upgrading from the former screenshot map.
        self.map_width,self.map_height=1306,681
        self.setSceneRect(QRectF(0,0,self.map_width,self.map_height))
        self.setRenderHints(QPainter.RenderHint.Antialiasing|QPainter.RenderHint.SmoothPixmapTransform)
        self.setTransformationAnchor(QGraphicsView.ViewportAnchor.AnchorUnderMouse)
        self.setResizeAnchor(QGraphicsView.ViewportAnchor.AnchorViewCenter)
        self.setViewportUpdateMode(QGraphicsView.ViewportUpdateMode.FullViewportUpdate)
        self.setBackgroundBrush(QBrush(color('#0b111c')))
        self.setMouseTracking(True)
        self.mode='pan'
        self.overlay_items=[]
        self.a=None;self.b=None
        self.stations=[];self.drone=None;self.trail=[]
        self.show_routes=True;self.show_storm=True;self.show_drones=True;self.show_stations=True;self.show_trail=True
        self.selected_route='direct'
        self.routes=[]
        self.astronaut=None
        self.weather_points=[]
        self.show_temperature=True
        self.show_astronaut=True
        self.wind_phase=0
        self.thematic_item=None
        self.route_seed=0
        self.storm_origin=QPointF(self.map_width*.52,self.map_height*.56)
        self.storm_radius=72
        self.storm_bearing=35
        self.update_mode('pan')
        self.tiles=NasaTiles(self)

    def lonlat(self,x,y):
        return x/self.map_width*360-180,90-y/self.map_height*180

    def from_lonlat(self,longitude,latitude):
        return (longitude+180)/360*self.map_width,(90-latitude)/180*self.map_height

    def fit_map(self):
        self.fitInView(self.sceneRect(),Qt.AspectRatioMode.KeepAspectRatio)

    def set_thematic_image(self,image):
        if self.thematic_item is not None:self.scene_.removeItem(self.thematic_item)
        self.thematic_item=self.scene_.addPixmap(QPixmap.fromImage(image))
        self.thematic_item.setTransform(QTransform.fromScale(self.map_width/image.width(),self.map_height/image.height()))
        self.thematic_item.setZValue(-40)
        self.thematic_item.setOpacity(.94)
        self.thematic_item.setTransformationMode(Qt.TransformationMode.FastTransformation)

    def update_mode(self,mode):
        self.mode=mode
        self.setDragMode(QGraphicsView.DragMode.ScrollHandDrag if mode=='pan' else QGraphicsView.DragMode.NoDrag)
        self.setCursor(Qt.CursorShape.OpenHandCursor if mode=='pan' else Qt.CursorShape.CrossCursor)

    def wheelEvent(self,event):
        factor=1.18 if event.angleDelta().y()>0 else 1/1.18
        if .1 < self.transform().m11()*factor < 128: self.scale(factor,factor)

    def mousePressEvent(self,event):
        if event.button()==Qt.MouseButton.LeftButton and self.mode!='pan':
            p=self.mapToScene(event.position().toPoint())
            if self.sceneRect().contains(p):
                self.map_clicked.emit(p.x(),p.y())
                event.accept();return
        super().mousePressEvent(event)

    def mouseMoveEvent(self,event):
        p=self.mapToScene(event.position().toPoint())
        if self.sceneRect().contains(p):self.cursor_changed.emit(p.x(),p.y())
        super().mouseMoveEvent(event)

    def add_item(self,it,z=4):
        self.scene_.addItem(it);it.setZValue(z);self.overlay_items.append(it)
        return it

    def add_line(self,p1,p2,stroke,width=2,dash=False,z=3):
        from PySide6.QtWidgets import QGraphicsLineItem
        pen=QPen(color(stroke),width,Qt.PenStyle.DashLine if dash else Qt.PenStyle.SolidLine)
        pen.setCosmetic(True)
        return self._line(p1,p2,pen,z)

    def _line(self,p1,p2,pen,z):
        it=self.scene_.addLine(p1[0],p1[1],p2[0],p2[1],pen)
        it.setZValue(z);self.overlay_items.append(it)
        return it

    def marker(self,x,y,label,fill,radius=7,z=6,interactive_id=None):
        if interactive_id:
            ellipse=MarkerItem(x,y,radius,interactive_id,lambda name:self.marker_clicked.emit(name))
            ellipse.setPen(QPen(QColor('white'),1.5))
            ellipse.setBrush(QBrush(color(fill)))
            self.add_item(ellipse,z)
        else:
            ellipse=self.scene_.addEllipse(-radius,-radius,radius*2,radius*2,
                QPen(QColor('white'),1.5),QBrush(color(fill)))
            ellipse.setPos(x,y)
            ellipse.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIgnoresTransformations)
            ellipse.setZValue(z);self.overlay_items.append(ellipse)
        if interactive_id:
            ellipse.setToolTip(f"{label} — {interactive_id}")
            ellipse.setCursor(Qt.CursorShape.PointingHandCursor)
            ellipse.setData(0,interactive_id)
        txt=self.scene_.addText(label,QFont('DejaVu Sans',9,QFont.Weight.Bold))
        txt.setParentItem(ellipse)
        txt.setDefaultTextColor(QColor('white'))
        txt.setPos(radius+4,-radius-10)
        txt.setZValue(z+1)
        self.overlay_items.append(txt)

    def render_overlay(self):
        for it in self.overlay_items:
            if it.scene() is self.scene_:self.scene_.removeItem(it)
        self.overlay_items=[]
        for record in self.weather_points:
            x,y=self.from_lonlat(*record['position'])
            if self.show_temperature:
                lo=record.get('ground_min_c');hi=record.get('ground_max_c');kind='Гадарга'
                if lo is None or hi is None:lo=record.get('min_c');hi=record.get('max_c');kind='Агаар'
                if lo is not None and hi is not None:
                    tint=temperature_color(hi)
                    gradient=QRadialGradient(0,0,34)
                    center=QColor(tint);center.setAlpha(180)
                    edge=QColor(tint);edge.setAlpha(0)
                    gradient.setColorAt(0,center);gradient.setColorAt(.5,center);gradient.setColorAt(1,edge)
                    patch=self.scene_.addEllipse(-34,-34,68,68,QPen(Qt.PenStyle.NoPen),QBrush(gradient))
                    patch.setPos(x,y);patch.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIgnoresTransformations)
                    patch.setData(0,'temperature')
                    patch.setToolTip(f"{record['name']}\n{kind}: {lo:g}…{hi:g} °C\n{record['date']}")
                    self.add_item(patch,1)
            speed=record.get('wind_mps');bearing=record.get('wind_deg')
            if self.show_storm and speed is not None and bearing is not None:
                # A local wind-direction indicator, not an invented moving storm footprint.
                angle=math.radians(270-bearing)
                length=30/max(.1,self.transform().m11())
                dx=math.cos(angle)*length;dy=-math.sin(angle)*length
                stroke=wind_color(speed)
                self.add_line((x,y),(x+dx,y+dy),stroke,2,z=5)
                phase=self.wind_phase
                self.marker(x+dx*phase,y+dy*phase,f'{speed:g} м/с',stroke,4,z=6)
        if self.show_routes and self.a and self.b:
            for route in self.routes:
                path=QPainterPath(QPointF(*route['points'][0]))
                previous=route['points'][0]
                for p in route['points'][1:]:
                    if abs(p[0]-previous[0])>self.map_width/2:path.moveTo(QPointF(*p))
                    else:path.lineTo(QPointF(*p))
                    previous=p
                obj=RouteItem(path,route,lambda key:self.route_clicked.emit(key),route['key']==self.selected_route)
                self.add_item(obj,2 if route['key']!=self.selected_route else 3)
        if self.show_stations:
            for i,s in enumerate(self.stations):
                if i:
                    last=self.stations[i-1]
                    self.add_line((last['x'],last['y']),(s['x'],s['y']),'#77a8d7',1.4,True,z=2)
                state=s.get('status','NORMAL')
                danger=s.get('reading',{}).get('risk',0)>=40
                broken=state in ('BROKEN','SENSOR_FAILURE','LINK_TIMEOUT')
                fill='#ff454f' if broken else '#ffb454' if danger or state=='LOW_POWER' else '#73bbec'
                caption=s['id']+(' · ЭВДЭРСЭН' if broken else ' ⚠' if danger else '')
                self.marker(s['x'],s['y'],caption,fill,7,interactive_id=s['id'])
        if self.show_trail and len(self.trail)>1:
            for p,q in zip(self.trail,self.trail[1:]):
                self.add_line(p,q,'#a5b4c3',3,False,z=4).setOpacity(.45)
        if self.show_drones and self.drone:
            self.marker(*self.drone,'DRONE-01','#c3a6ff',7,interactive_id='DRONE-01')
        if self.show_astronaut and self.astronaut:
            person=AstronautItem(*self.astronaut,self.marker_clicked.emit);self.add_item(person,9)
            txt=self.scene_.addText('EVA-01',QFont('Segoe UI',9,QFont.Weight.Bold))
            txt.setParentItem(person);txt.setPos(16,8);txt.setDefaultTextColor(QColor('white'))
            self.overlay_items.append(txt)
        if self.a:self.marker(*self.a,'A','#59e6bd',9,z=8)
        if self.b:self.marker(*self.b,'B','#ff836f',9,z=8)
