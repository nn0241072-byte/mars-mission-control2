"""Mars Mission Control — pure native PySide6 user interface."""
import json
from pathlib import Path
from PySide6.QtCore import Qt, QTimer, QSettings, QThreadPool, QRectF
from PySide6.QtGui import QAction, QActionGroup, QColor, QPalette, QFont, QFontDatabase
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QHBoxLayout, QVBoxLayout, QLabel, QPushButton,
    QDockWidget, QFrame, QFormLayout, QDoubleSpinBox, QComboBox, QCheckBox,
    QListWidget, QListWidgetItem, QTabWidget, QScrollArea, QTextEdit, QFileDialog,
    QMessageBox, QToolBar, QSplitter, QStatusBar, QGroupBox, QProgressBar,
    QSpinBox, QDialog, QDialogButtonBox, QInputDialog, QSizePolicy
)
from ui.map_view import MarsView
from services.planner import Mobility, plan_routes
from services.terrain import fetch_terrain, distance_km
from services.science import Job, fetch_weather, wind_color
from services.nasa_tiles import NasaTiles
from services.thematic import fetch_global_elevation,ELEVATION_COLORS,ELEVATION_LABELS
from storage.database import MissionDB
from services.backend import BackendClient


APP_DIR=Path(__file__).resolve().parents[1]
DATA_DIR=Path.home()/'.mars_mission_control'
DATA_DIR.mkdir(parents=True,exist_ok=True)


def label(text, bold=False):
    w=QLabel(text)
    if bold:
        f=w.font();f.setBold(True);w.setFont(f)
    w.setWordWrap(True)
    return w


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('МАРС ГАЗРЫН ЗУРАГ')
        self.resize(1510,920)
        self.db=MissionDB(DATA_DIR/'mission_nasa.sqlite3')
        self.map=MarsView()
        self.settings=QSettings('MarsMission','Control')
        self.terrain_grid=None
        self.route_request=0
        self.route_signature=None
        self.science_jobs={}
        self._closed=False
        self.route_debounce=QTimer(self);self.route_debounce.setSingleShot(True);self.route_debounce.setInterval(400)
        self.route_debounce.timeout.connect(self._calculate_routes)
        self.thermal_tiles=None
        self.elevation_grid=None
        self.wind=None
        self.temperature=None
        self.weather=None
        self.photo_path=None
        self.photo_signature=None
        self.photo_folder=Path(self.settings.value('photo_folder',str(DATA_DIR/'drone_inbox')))
        self.photo_folder.mkdir(parents=True,exist_ok=True)
        self.selected_route='direct'
        self.map.selected_route=self.selected_route
        self.moving_station=None
        self.station_count=0
        self.drone_battery=None
        self.drone_altitude=None
        self.drone_photos=[]
        self.storm_counter=0
        self._apply_palette()
        self._load_saved_state()
        self.setCentralWidget(self.map)
        self._make_toolbar()
        self._make_right_dock()
        self._make_bottom_dock()
        self._make_photo_overlay()
        self._make_zone_legend()
        self._make_statusbar()
        self.map.map_clicked.connect(self._map_click)
        self.map.route_clicked.connect(self._route_selected)
        self.map.marker_clicked.connect(self._marker_selected)
        self.map.cursor_changed.connect(self._map_coordinates)
        self.map.tiles.status_changed.connect(self._map_source_changed)
        self.map.render_overlay()
        QTimer.singleShot(150,self.map.fit_map)
        self.storm_timer=QTimer(self)
        self.storm_timer.timeout.connect(self._storm_step)
        self.storm_timer.start(180)
        self.photo_timer=QTimer(self)
        self.photo_timer.timeout.connect(self._poll_drone_photos)
        self.photo_timer.start(1500)
        self._update_storm()
        for station in self.map.stations:self._sample_station(station)
        self._poll_drone_photos()
        self._update_all()
        self.backend_connected=False
        self.backend_data=None
        self.backend_image_reference=None
        self.backend_pixmap=None
        self.backend=BackendClient(self)
        self.backend.dashboard_received.connect(self._backend_received)
        self.backend.failed.connect(self._backend_failed)
        self.backend.image_received.connect(self._backend_image_received)
        self.backend.image_failed.connect(self._backend_image_failed)
        self.backend.start()
        self._schedule_routes()
        self._load_nasa_weather()
        self.science_timer=QTimer(self);self.science_timer.timeout.connect(self._load_nasa_weather);self.science_timer.start(900000)
        QTimer.singleShot(0,lambda:self.thematic_check.setChecked(True) if not self._closed else None)

    def _apply_palette(self):
        if not QFontDatabase.families():
            import os
            for filename in ('segoeui.ttf','segoeuib.ttf'):
                font_path=Path(os.environ.get('WINDIR','C:/Windows'))/'Fonts'/filename
                if font_path.exists():QFontDatabase.addApplicationFont(str(font_path))
        p=QPalette()
        p.setColor(QPalette.ColorRole.Window,QColor('#101722'))
        p.setColor(QPalette.ColorRole.WindowText,QColor('#e7edf5'))
        p.setColor(QPalette.ColorRole.Base,QColor('#172130'))
        p.setColor(QPalette.ColorRole.AlternateBase,QColor('#202c3a'))
        p.setColor(QPalette.ColorRole.Text,QColor('#e7edf5'))
        p.setColor(QPalette.ColorRole.Button,QColor('#243245'))
        p.setColor(QPalette.ColorRole.ButtonText,QColor('#f1f6fa'))
        p.setColor(QPalette.ColorRole.Highlight,QColor('#457b9d'))
        p.setColor(QPalette.ColorRole.HighlightedText,QColor('#ffffff'))
        p.setColor(QPalette.ColorRole.ToolTipBase,QColor('#253b4b'))
        p.setColor(QPalette.ColorRole.ToolTipText,QColor('#f4f7f9'))
        self.setPalette(p)
        self.setFont(QFont('Segoe UI',10))
        self.setStyleSheet("""
            QMainWindow, QWidget { color: #e7edf5; }
            QDockWidget { font-weight: 600; }
            QDockWidget::title { background: #162333; padding: 12px; }
            QTabWidget::pane { border: 0; background: #111e2c; }
            QTabBar::tab { padding: 11px 12px; background: #172638; color: #a2b5ca; }
            QTabBar::tab:selected { color: #70e3cf; border-bottom: 2px solid #70e3cf; }
            QPushButton, QToolButton { background: #20364a; border: 1px solid #324e64;
                border-radius: 7px; padding: 9px; }
            QPushButton:hover, QToolButton:hover { background: #2a4860; }
            QToolButton:checked { background: #236759; color: white; }
            QListWidget { background: #101c29; border: 1px solid #293d51; border-radius: 8px; }
            QListWidget::item { padding: 12px 8px; border-bottom: 1px solid #203145; }
            QListWidget::item:selected { background: #20483f; color: #b8fff0; }
            QDoubleSpinBox, QSpinBox, QComboBox, QLineEdit {
                background: #142333; border: 1px solid #345066; border-radius: 5px; padding: 6px; }
            QToolBar { background: #111e2c; border: 0; spacing: 7px; padding: 8px; }
            QStatusBar { background: #111e2c; color: #9fb3c9; }
            QLabel#dataBadge { background: #12352f; color: #7ce7cb; border: 1px solid #23544b;
                border-radius: 8px; padding: 9px; font-size: 11px; }
            QLabel#metricCard { background: #192b3a; border: 1px solid #304c60;
                border-radius: 10px; padding: 16px; font-size: 13px; line-height: 1.6; }
            QLabel#muted { color: #92a6b7; font-size: 11px; }
            QToolButton { min-width: 68px; padding: 10px 6px; margin-bottom: 3px; }
            QToolButton:checked { border: 1px solid #61d6bc; background: #1b4a43; }
            QScrollArea { border: none; background: transparent; }
            QScrollBar:vertical { background: #12202d; width: 9px; }
            QScrollBar::handle:vertical { background: #365366; border-radius: 4px; min-height: 24px; }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
        """)

    def _load_saved_state(self):
        self.map.a=self.map.from_lonlat(-8.78906233605261,-8.789062336052638)
        self.map.b=self.map.from_lonlat(-120.09,-8.35) # Arsia Mons; illustrative destination
        self.map.drone=self.map.from_lonlat(-10.,-9.)
        self.map.stations=[]
        for m in self.db.markers():
            p=(m['x'],m['y'])
            if m['id']=='POINT_A':self.map.a=p
            elif m['id']=='POINT_B':self.map.b=p
            elif m['id']=='DRONE-01':self.map.drone=p
            elif m['id']=='ASTRONAUT-01':self.map.astronaut=p
            elif m['kind']=='station':self.map.stations.append(m)
        self.station_count=max([int(s['id'].split('-')[-1]) for s in self.map.stations if s['id'].split('-')[-1].isdigit()] or [0])
        self.map.trail=[(t[0],t[1]) for t in self.db.trail()]
        self.db.upsert_marker('POINT_A','landing',*self.map.a)
        self.db.upsert_marker('POINT_B','destination',*self.map.b)
        self.db.upsert_marker('DRONE-01','drone',*self.map.drone)

    def _make_toolbar(self):
        bar=QToolBar('Map Tools',self)
        bar.setMovable(False)
        bar.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextUnderIcon)
        self.addToolBar(Qt.ToolBarArea.LeftToolBarArea,bar)
        group=QActionGroup(self);group.setExclusive(True)
        self.mode_actions={}
        tools=[('Гүйлгэх','pan'),('A эхлэл','a'),('B зорилго','b'),('Нисгэгч','astronaut'),('Станц','station'),('Дрон','drone'),('Явсан мөр','track')]
        for title,mode in tools:
            act=QAction(title,self);act.setCheckable(True);act.setData(mode)
            if mode=='pan':act.setChecked(True)
            self.mode_actions[mode]=act
            group.addAction(act);bar.addAction(act)
            act.triggered.connect(lambda checked,m=mode:self._mode(m))
        bar.addSeparator()
        fit=QAction('Бүтнээр харах',self);fit.triggered.connect(self.map.fit_map);bar.addAction(fit)
        right=QAction('Маршрут',self);right.triggered.connect(lambda:self.right_dock.show());bar.addAction(right)
        bottom=QAction('Дрон / Станц',self);bottom.triggered.connect(self._show_telemetry);bar.addAction(bottom)
        back=QAction('← Буцах (Esc)',self);back.setShortcut('Escape')
        back.triggered.connect(self._back_to_map);bar.addAction(back)

    def _mode(self,mode):
        self.map.update_mode(mode)
        if mode in self.mode_actions:self.mode_actions[mode].setChecked(True)
        self.statusBar().showMessage(f'{mode.upper()}',6000)

    def _back_to_map(self):
        self.moving_station=None
        self._mode('pan')
        self.bottom_dock.hide()
        self.map.setFocus()
        self.statusBar().showMessage('Газрын зураг руу буцлаа.',4000)

    def _show_telemetry(self):
        self.bottom_dock.show()
        self.resizeDocks([self.bottom_dock],[min(400,max(220,self.height()//2))],Qt.Orientation.Vertical)

    def _make_right_dock(self):
        self.right_dock=QDockWidget('МАРС ГАЗРЫН ЗУРАГ',self)
        self.right_dock.setObjectName('route_dock')
        self.right_dock.setAllowedAreas(Qt.DockWidgetArea.RightDockWidgetArea)
        outer=QWidget();layout=QVBoxLayout(outer)
        layout.setContentsMargins(10,10,10,10)
        title=label('МАРС ГАЗРЫН ЗУРАГ',True)
        title.setStyleSheet('font-size:16px; letter-spacing:1px; padding:8px 0; color:#e5f4f4;')
        layout.addWidget(title)
        self.map_source_status=label('NASA Trek: connecting…')
        self.map_source_status.setTextFormat(Qt.TextFormat.PlainText)
        layout.addWidget(self.map_source_status)
        self.station_alert=label('Станцын мэдээлэл • Станц байрлуулж эхэлнэ үү.')
        self.station_alert.setStyleSheet('padding: 10px; background: #20364a; border-radius: 7px;')
        layout.addWidget(self.station_alert)
        tabs=QTabWidget()
        tabs.addTab(self._route_tab(),'Маршрут')
        tabs.addTab(self._weather_tab(),'Цаг агаар')
        tabs.addTab(self._layer_tab(),'Давхарга')
        tabs.addTab(self._history_tab(),'Түүх')
        tabs.addTab(self._backend_tab(),'Backend')
        container=QScrollArea();container.setWidgetResizable(True);container.setWidget(tabs)
        container.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        layout.addWidget(container,1)
        self.right_dock.setWidget(outer)
        self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea,self.right_dock)
        self.right_dock.setMinimumWidth(400)
        self.right_dock.resize(410,600)

    def _route_tab(self):
        w=QWidget();v=QVBoxLayout(w);v.setSpacing(12)
        self.route_state=label('NASA MOLA · өндөршил татаж байна…')
        self.route_state.setObjectName('dataBadge');v.addWidget(self.route_state)
        self.route_list=QListWidget();self.route_list.setFixedHeight(195)
        self.route_list.setWordWrap(True);self.route_list.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.route_list.currentRowChanged.connect(self._route_from_list);v.addWidget(self.route_list)
        actions=QHBoxLayout()
        fit=QPushButton('Зам харах');fit.clicked.connect(self._fit_route);actions.addWidget(fit)
        refresh=QPushButton('Дахин тооцоолох');refresh.clicked.connect(self._schedule_routes);actions.addWidget(refresh)
        v.addLayout(actions)
        form=QFormLayout()
        self.profile_combo=QComboBox();self.profile_combo.addItems(['Сансрын нисгэгч','Ровер'])
        form.addRow('Хөдөлгөөн',self.profile_combo)
        self.speed_spin=QDoubleSpinBox();self.speed_spin.setRange(.1,30);self.speed_spin.setValue(3);self.speed_spin.setSuffix(' км/ц')
        form.addRow('Суурь хурд',self.speed_spin)
        self.power_spin=QDoubleSpinBox();self.power_spin.setRange(1,5000);self.power_spin.setValue(250);self.power_spin.setSuffix(' W')
        form.addRow('Суурь зарцуулалт',self.power_spin)
        self.mass_spin=QDoubleSpinBox();self.mass_spin.setRange(1,5000);self.mass_spin.setValue(150);self.mass_spin.setSuffix(' кг')
        form.addRow('Нийт масс',self.mass_spin)
        parameters=QWidget();parameters.setLayout(form);parameters.hide()
        settings=QPushButton('Хөдөлгөөний тохиргоо');settings.setCheckable(True)
        settings.toggled.connect(parameters.setVisible)
        v.addWidget(settings);v.addWidget(parameters)
        self.profile_combo.currentIndexChanged.connect(self._profile_changed)
        for spin in (self.speed_spin,self.power_spin,self.mass_spin):spin.valueChanged.connect(self._schedule_routes)
        self.route_info=label('');self.route_info.setObjectName('metricCard');v.addWidget(self.route_info)
        self.route_notes=label('');self.route_notes.setObjectName('muted');v.addWidget(self.route_notes)
        btn=QPushButton('Маршрут хадгалах');btn.clicked.connect(self._save_route);v.addWidget(btn)
        v.addStretch();return w

    def _weather_tab(self):
        w=QWidget();v=QVBoxLayout(w);v.setSpacing(14)
        v.addWidget(label('NASA · ЦАГ АГААР',True))
        self.weather_label=label('Хэмжилт татаж байна…');v.addWidget(self.weather_label)
        self.storm_note=label('Салхины хэмжилт —');v.addWidget(self.storm_note)
        legend=label('')
        legend.setText('<span style="color:#59d9b6">● &lt;15</span>  <span style="color:#f1ce6b">● 15–30</span>  <span style="color:#ff9c55">● 30–55</span>  <span style="color:#f05264">● ≥55 м/с</span>')
        v.addWidget(legend)
        v.addWidget(label('Салхины ангилал · төслийн босго утгууд'))
        self.backend_weather=label('Backend · хэмжилт хүлээж байна');self.backend_weather.setTextFormat(Qt.TextFormat.PlainText)
        v.addWidget(self.backend_weather);v.addStretch();return w

    def _layer_tab(self):
        w=QWidget();v=QVBoxLayout(w);v.setSpacing(14)
        self.thematic_check=QCheckBox('Өнгөт бүсчлэл · өндөршил')
        self.thematic_check.toggled.connect(self._toggle_thematic);v.addWidget(self.thematic_check)
        self.thematic_status=label('NASA MOLA · метр');self.thematic_status.setObjectName('muted');v.addWidget(self.thematic_status)
        self.layer_checks={}
        for name,attr,checked in [('Маршрут','show_routes',True),('Температур','show_temperature',True),('Салхи','show_storm',True),('Сансрын нисгэгч','show_astronaut',True),('Дрон','show_drones',True),('Станцууд','show_stations',True),('Явсан мөр','show_trail',True)]:
            check=QCheckBox(name);check.setChecked(checked)
            self.layer_checks[attr]=check
            check.toggled.connect(lambda value,at=attr:self._toggle_layer(at,value));v.addWidget(check)
        self.temperature_legend=label('Өдрийн их температур · °C')
        self.temperature_legend.setObjectName('muted');v.addWidget(self.temperature_legend)
        bar=QFrame();bar.setFixedHeight(12)
        bar.setStyleSheet('border-radius:6px; background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #4269dd,stop:0.31 #40c8df,stop:0.62 #f2d36c,stop:1 #ed6254);')
        v.addWidget(bar)
        v.addWidget(label('−100               −60               −20               +30'))
        self.temperature_records=label('NASA · хэмжилт татаж байна…')
        self.temperature_records.setObjectName('metricCard');v.addWidget(self.temperature_records)
        coverage=label('Өнгө нь зөвхөн хэмжилтийн цэгийг тэмдэглэнэ.')
        coverage.setObjectName('muted');v.addWidget(coverage)
        self.thermal_check=QCheckBox('THEMIS · өдрийн дулааны зураг')
        self.thermal_check.toggled.connect(self._toggle_thermal);v.addWidget(self.thermal_check)
        self.thermal_status=label('');v.addWidget(self.thermal_status)
        v.addWidget(label('THEMIS · архивын хэт улаан зураг, °C биш.'))
        source=QPushButton('Өгөгдлийн эх сурвалж');source.clicked.connect(self._show_sources);v.addWidget(source)
        v.addStretch();return w

    def _history_tab(self):
        w=QWidget();v=QVBoxLayout(w)
        self.events_list=QListWidget();v.addWidget(self.events_list)
        b=QPushButton('Refresh history');b.clicked.connect(self._update_events);v.addWidget(b)
        clear=QPushButton('Clear recorded travel trail')
        clear.clicked.connect(self._clear_trail);v.addWidget(clear)
        v.addWidget(label('Use “Add Track Point” in the left toolbar and click successive visited positions. Each point is timestamped and saved.'))
        return w

    def _make_bottom_dock(self):
        self.bottom_dock=QDockWidget('ДРОН / СТАНЦЫН СҮЛЖЭЭ',self)
        self.bottom_dock.setObjectName('telemetry_dock')
        self.bottom_dock.setAllowedAreas(Qt.DockWidgetArea.BottomDockWidgetArea)
        tabs=QTabWidget()
        tabs.addTab(self._drone_tab(),'Drone-01')
        tabs.addTab(self._stations_tab(),'Станцууд')
        self.bottom_dock.setWidget(tabs)
        self.addDockWidget(Qt.DockWidgetArea.BottomDockWidgetArea,self.bottom_dock)
        self.bottom_dock.setMinimumHeight(180)
        self.bottom_dock.setSizePolicy(QSizePolicy.Policy.Preferred,QSizePolicy.Policy.Preferred)
        self.bottom_dock.hide()

    def _drone_tab(self):
        w=QWidget();v=QVBoxLayout(w)
        self.drone_stats=label('');v.addWidget(self.drone_stats)
        controls=QHBoxLayout()
        upload=QPushButton('Дроны зураг нээх');upload.clicked.connect(self._open_drone_photo);controls.addWidget(upload)
        folder=QPushButton('Зургийн хавтас');folder.clicked.connect(self._choose_photo_folder);controls.addWidget(folder)
        v.addLayout(controls)
        self.folder_label=label(str(self.photo_folder));v.addWidget(self.folder_label)
        return w

    def _stations_tab(self):
        w=QWidget();root=QVBoxLayout(w)
        root.setContentsMargins(10,8,10,8)
        back=QPushButton('← Газрын зураг руу буцах (Esc)')
        back.clicked.connect(self._back_to_map);root.addWidget(back,0,Qt.AlignmentFlag.AlignLeft)
        v=QHBoxLayout();root.addLayout(v,1)
        col=QVBoxLayout()
        self.station_list=QListWidget();self.station_list.setMinimumSize(120,60)
        self.station_list.currentRowChanged.connect(self._station_selected)
        col.addWidget(self.station_list)
        col.addWidget(label('Станц нэмэх товчийг сонгоод газрын зураг дээр дарна уу. Шууд хадгалагдана.'))
        v.addLayout(col,2)
        details=QWidget();side=QVBoxLayout(details)
        details.setMinimumWidth(270)
        self.station_scroll=QScrollArea()
        self.station_scroll.setWidgetResizable(True)
        self.station_scroll.setMinimumSize(150,60)
        self.station_scroll.setWidget(details)
        self.station_scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.station_info=label('')
        side.addWidget(self.station_info)
        self.station_status=QComboBox();self.station_status.addItems(['NORMAL','LOW_POWER','LINK_TIMEOUT','SENSOR_FAILURE','BROKEN'])
        self.station_status.setItemText(4,'BROKEN — Эвдэрсэн')
        self.station_status.setItemData(4,'BROKEN')
        side.addWidget(self.station_status)
        change=QPushButton('Станцын төлөв хадгалах')
        change.clicked.connect(self._set_station_status)
        side.addWidget(change)
        rename=QPushButton('Нэр өөрчлөх');rename.clicked.connect(self._rename_station);side.addWidget(rename)
        move=QPushButton('Байршил өөрчлөх');move.clicked.connect(self._move_station);side.addWidget(move)
        self.delete_station_button=QPushButton('Сонгосон станцыг устгах')
        self.delete_station_button.setStyleSheet('QPushButton { background: #652d38; border: 1px solid #e65a67; } QPushButton:disabled { background: #26303c; border-color: #344052; color: #788595; }')
        self.delete_station_button.setEnabled(False)
        self.delete_station_button.clicked.connect(self._delete_station);side.addWidget(self.delete_station_button)
        side.addWidget(label('Станцын өөрчлөлт бүр автоматаар хадгалагдана.'))
        side.addStretch()
        v.addWidget(self.station_scroll,3)
        return w

    def _backend_tab(self):
        w=QWidget();v=QVBoxLayout(w)
        v.addWidget(label('BACKEND TELEMETRY',True))
        v.addWidget(label('Backend · 3 секунд тутам шинэчлэгдэнэ'))
        self.backend_summary=label('Waiting for backend dashboard…')
        self.backend_summary.setTextFormat(Qt.TextFormat.PlainText)
        v.addWidget(self.backend_summary)
        self.backend_photo=QPushButton('Waiting for drone photo')
        self.backend_photo.setMinimumHeight(110)
        self.backend_photo.clicked.connect(self._enlarge_backend_photo)
        v.addWidget(self.backend_photo)
        self.backend_photo_caption=label('Backend drone image • no capture received')
        self.backend_photo_caption.setTextFormat(Qt.TextFormat.PlainText)
        v.addWidget(self.backend_photo_caption)
        self.backend_reports=QTextEdit();self.backend_reports.setReadOnly(True)
        v.addWidget(self.backend_reports,1)
        return w

    @staticmethod
    def _backend_source(record):
        value=record.get('simulated')
        return 'SIMULATED' if value is True else 'NON-SIMULATED (reported by backend)' if value is False else 'SOURCE UNKNOWN'

    def _backend_received(self,data):
        self.backend_connected=True
        self.backend_data=data
        self.backend_status.setText('Backend: Connected • prototype')
        self.backend_status.setToolTip(self.backend.base_url.toString())
        self.backend_status.setStyleSheet('color: #70e3cf;')
        self._render_backend()
        photo=data.get('latestDroneImage')
        reference=photo.get('imageUrl') if photo else None
        if reference != self.backend_image_reference:
            self.backend_image_reference=reference
            self.backend_pixmap=None
            from PySide6.QtGui import QIcon
            self.backend_photo.setIcon(QIcon())
        if reference and self.backend_pixmap is None:
            self.backend_photo.setText('Loading backend drone photo…')
            self.backend.fetch_image(reference)
        elif not reference:
            self.backend_photo.setText('Waiting for drone photo')

    def _backend_failed(self,message):
        self.backend_connected=False
        self.backend_status.setText('Backend: Disconnected • retained data is historical')
        self.backend_status.setStyleSheet('color: #ffb454;')
        self.backend_status.setToolTip(message)
        self._render_backend()

    def _render_backend(self):
        data=self.backend_data
        if data is None:
            self.backend_summary.setText('Disconnected • waiting for first dashboard. Check backend address and server.')
            self.backend_weather.setText('Backend weather: disconnected • no readings received')
            return
        state='Connected' if self.backend_connected else 'DISCONNECTED — cached snapshot, freshness no longer verified'
        posts=data['posts']
        self.backend_summary.setText(f"{state}\nServer snapshot: {data.get('serverTime','unknown')}\nMission: {data.get('missionId','unknown')} • {len(posts)} backend station(s)")
        lines=[]
        weather_lines=[]
        for post in posts:
            lines.extend([f"STATION {post.get('postId','unknown')} • {self._backend_source(post)}",
                f"Observed: {post.get('observedAt','unknown')} • received: {post.get('receivedAt','unknown')}",
                'Position: '+json.dumps(post.get('position',{}),ensure_ascii=False)])
            for name,reading in post.get('layers',{}).items():
                lines.append(f"{name.upper()} • {reading.get('status','unknown')}\n"+json.dumps(reading,ensure_ascii=False,indent=2))
                if name=='weather':
                    weather_lines.append(
                        f"{post.get('postId','unknown')} • {self._backend_source(post)} • {reading.get('status','unknown')}\n"
                        f"{reading.get('airTemperatureC','unknown')} °C • {reading.get('pressurePa','unknown')} Pa\n"
                        f"Wind: {reading.get('windSpeedMps','unknown')} m/s • {reading.get('windDirectionDeg','unknown')}°\n"
                        f"Observed: {reading.get('observedAt','unknown')}")
            power=post.get('power',{})
            lines.append(f"POWER / BATTERIES • {power.get('status','unknown')}\n"+json.dumps(power,ensure_ascii=False,indent=2))
            lines.append('')
        if not posts:
            lines.append('Waiting for station telemetry. No backend weather or battery inventory received.')
        lines.extend(['DASHBOARD LAYERS (backend source and freshness labels)',
                      json.dumps(data['layers'],ensure_ascii=False,indent=2)])
        # Plain text prevents captions and identifiers from being interpreted as markup.
        scroll=self.backend_reports.verticalScrollBar().value()
        self.backend_reports.setPlainText('\n'.join(lines))
        self.backend_reports.verticalScrollBar().setValue(scroll)
        self.backend_weather.setText('BACKEND WEATHER • '+state+'\n'+('\n\n'.join(weather_lines) or 'Waiting for weather readings'))
        photo=data.get('latestDroneImage')
        if photo:
            self.backend_photo_caption.setText(
                f"{self._backend_source(photo)} • {photo.get('status','unknown')}\n"
                f"Captured: {photo.get('capturedAt','unknown')}\n"
                f"{photo.get('caption','')}\n"+('Historical snapshot; disconnected' if not self.backend_connected else 'Snapshot image; not a live camera feed'))
            self.backend_photo_caption.setToolTip(json.dumps(photo,ensure_ascii=False,indent=2))
        else:
            self.backend_photo_caption.setText('Waiting for drone photo • backend has no matching capture')

    def _backend_image_received(self,reference,content):
        if reference!=self.backend_image_reference:return
        from PySide6.QtGui import QPixmap,QIcon
        from PySide6.QtCore import QSize
        pix=QPixmap()
        if not pix.loadFromData(content):
            self._backend_image_failed(reference,'Unsupported or invalid image');return
        self.backend_pixmap=pix
        self.backend_photo.setText('')
        self.backend_photo.setIcon(QIcon(pix))
        self.backend_photo.setIconSize(QSize(240,110))
        self.backend_photo.setToolTip('Click to enlarge backend image')

    def _backend_image_failed(self,reference,message):
        if reference!=self.backend_image_reference:return
        self.backend_photo.setText('Backend photo unavailable • retrying on refresh')
        self.backend_photo.setToolTip(message)

    def _enlarge_backend_photo(self):
        if self.backend_pixmap is None:return
        dialog=QDialog(self);dialog.setWindowTitle('Backend drone snapshot');dialog.resize(900,700)
        layout=QVBoxLayout(dialog)
        layout.addWidget(label(self.backend_photo_caption.text()))
        scroll=QScrollArea();image=QLabel();image.setPixmap(self.backend_pixmap)
        scroll.setWidget(image);layout.addWidget(scroll)
        dialog.exec()

    def _make_statusbar(self):
        status=QStatusBar(self);self.setStatusBar(status)
        self.backend_status=label('Backend: Disconnected — connecting…')
        status.addWidget(self.backend_status,1)
        self.coords=label('NASA Mars • longitude / latitude • EPSG:104905')
        status.addPermanentWidget(self.coords)
        status.showMessage('NASA Trek · Mars')

    def _map_coordinates(self,x,y):
        longitude,latitude=self.map.lonlat(x,y)
        self.coords.setText(f'Mars longitude {longitude:.4f}° • latitude {latitude:.4f}° • EPSG:104905')
        if self.elevation_grid and self.thematic_check.isChecked():
            height=self.elevation_grid.sample((longitude,latitude))
            if height is not None:self.coords.setText(f'{longitude:.3f}° · {latitude:.3f}°   |   {height:.0f} м')

    def _map_click(self,x,y):
        mode=self.map.mode
        if mode=='station_move' and self.moving_station:
            station=next((s for s in self.map.stations if s['id']==self.moving_station),None)
            if station:
                station['x'],station['y']=x,y
                self.db.upsert_marker(station['id'],'station',x,y,station['status'])
                self._sample_station(station)
            self.moving_station=None;self._mode('pan')
        elif mode=='a':
            self.map.a=(x,y);self.db.upsert_marker('POINT_A','landing',x,y);self.db.add_event('landing_changed',x=x,y=y)
        elif mode=='b':
            self.map.b=(x,y);self.db.upsert_marker('POINT_B','destination',x,y);self.db.add_event('destination_changed',x=x,y=y)
        elif mode=='astronaut':
            self.map.astronaut=(x,y);self.db.upsert_marker('ASTRONAUT-01','astronaut',x,y)
        elif mode=='drone':
            self.map.drone=(x,y);self.db.upsert_marker('DRONE-01','drone',x,y);self.db.add_event('drone_moved',x=x,y=y)
        elif mode=='station':
            name,ok=QInputDialog.getText(self,'Станц нэмэх','Станцын нэр:',text=f'ST-{self.station_count+1:02d}')
            if not ok:return
            id=name.strip()
            if not id or any(m['id']==id for m in self.db.markers()):
                QMessageBox.information(self,'Станц','Давхцахгүй нэр оруулна уу.');return
            self.station_count+=1
            item={'id':id,'kind':'station','x':x,'y':y,'status':'NORMAL'}
            self.map.stations.append(item);self.db.upsert_marker(id,'station',x,y)
            self._sample_station(item)
            self.db.add_event('station_added',station=id,x=x,y=y,reading=item['reading'])
        elif mode=='track':
            self.map.trail.append((x,y));self.db.add_trail(x,y)
            self.db.add_event('travel_point_recorded',x=x,y=y)
        if mode in ('a','b'):self._schedule_routes()
        self._update_all()
        if mode=='station':
            self._show_telemetry()
            self.bottom_dock.widget().setCurrentIndex(1)
            self.station_list.setCurrentRow(len(self.map.stations)-1)

    def _marker_selected(self,name):
        if name=='ASTRONAUT-01':
            lon,lat=self.map.lonlat(*self.map.astronaut)
            self.statusBar().showMessage(f'EVA-01 · {lon:.4f}°, {lat:.4f}°',5000);return
        if name=='DRONE-01':
            self._show_telemetry()
            self.statusBar().showMessage('DRONE-01',5000)
            return
        self._show_telemetry()
        self.bottom_dock.widget().setCurrentIndex(1)
        for i,station in enumerate(self.map.stations):
            if station['id']==name:
                self.station_list.setCurrentRow(i)
                self.statusBar().showMessage(f'{name} selected — station diagnostics below.',5000)
                return

    def _route_selected(self,key):
        self.selected_route=key;self.map.selected_route=key
        self.map.render_overlay();self._update_routes()

    def _fit_route(self):
        route=next((r for r in self.map.routes if r['key']==self.selected_route),None)
        if not route:return
        xs=[p[0] for p in route['points']];ys=[p[1] for p in route['points']]
        rect=QRectF(min(xs),min(ys),max(.1,max(xs)-min(xs)),max(.1,max(ys)-min(ys)))
        margin=max(rect.width(),rect.height())*.2
        self.map.fitInView(rect.adjusted(-margin,-margin,margin,margin),Qt.AspectRatioMode.KeepAspectRatio)

    def _route_from_list(self,index):
        if 0<=index<len(self.map.routes) and self.map.routes[index]['key']!=self.selected_route:
            self._route_selected(self.map.routes[index]['key'])

    def _update_routes(self):
        routes=self.map.routes;keys=[route['key'] for route in routes]
        if self.selected_route not in keys:self.selected_route=keys[0] if keys else None
        self.map.selected_route=self.selected_route
        self.route_list.blockSignals(True);self.route_list.clear()
        for route in routes:
            item=QListWidgetItem(f"{route['name']}\n{route['distance_km']:.2f} км   ·   {route['hours']:.2f} ц   ·   {route['energy_wh']:.0f} Wh")
            item.setForeground(QColor(route['color']));self.route_list.addItem(item)
        unavailable=QListWidgetItem('Цацраг багатай маршрут\nОрон зайн тунгийн өгөгдөлгүй')
        unavailable.setFlags(Qt.ItemFlag.NoItemFlags);self.route_list.addItem(unavailable)
        if self.selected_route in keys:self.route_list.setCurrentRow(keys.index(self.selected_route))
        self.route_list.blockSignals(False)
        route=next((r for r in routes if r['key']==self.selected_route),None)
        if route:
            metrics=[('Зай',f"{route['distance_km']:.2f} км"),('Хугацаа',f"≈ {route['hours']:.2f} цаг"),('Энерги',f"≈ {route['energy_wh']:.0f} Wh"),('Өгсөлт',f"{route['ascent_m']:.0f} м"),('Их налуу',f"{route['max_slope_deg']:.2f}°"),('Налуугийн эрсдэл',route['risk']),('Цацрагийн тун','—')]
            rows=''.join(f'<tr><td style="color:#99b2c4">{key}</td><td align="right">{value}</td></tr>' for key,value in metrics)
            self.route_info.setText(f'<b>{route["name"]}</b><br><br><table width="100%" cellspacing="7">{rows}</table>')
            self.route_notes.setText(f"{route['profile']['name']} · {route['profile']['speed_kmh']:g} км/ц\nMOLA · {route['resolution_km']*1000:.0f} м нарийвчлал\nХугацаа / энерги: загвар. Чулуу, ан цав, шуургыг үнэлээгүй.")
        else:self.route_info.setText('');self.route_notes.setText('')

    def _save_route(self):
        route=next((r for r in self.map.routes if r['key']==self.selected_route),None)
        if not route:return
        self.db.add_event('nasa_route_selected',**route)
        self._update_events();self.statusBar().showMessage('Маршрут хадгаллаа',3000)

    def _update_storm(self):
        self.map.render_overlay()

    def _storm_step(self):
        self.map.wind_phase=(self.map.wind_phase+.08)%1
        if any(r.get('wind_mps') is not None and r.get('wind_deg') is not None for r in self.map.weather_points):self.map.render_overlay()

    def _toggle_layer(self,attr,value):
        if attr=='show_temperature' and value:self.thematic_check.setChecked(False)
        setattr(self.map,attr,value);self.map.render_overlay()

    def _update_drone(self):
        longitude,latitude=self.map.lonlat(*self.map.drone)
        self.drone_stats.setText(f"DRONE-01 · {longitude:.4f}°, {latitude:.4f}°\nӨндөр —   ·   Цэнэг —")

    def _open_drone_photo(self):
        path,_=QFileDialog.getOpenFileName(self,'Open a drone image','','Images (*.png *.jpg *.jpeg *.bmp *.webp)')
        if path:self._load_photo(Path(path))

    def _make_photo_overlay(self):
        self.photo_card=QFrame(self.map.viewport())
        self.photo_card.setStyleSheet('QFrame { background: #132333; border: 1px solid #456276; border-radius: 10px; }')
        self.photo_card.setFixedSize(240,175)
        layout=QVBoxLayout(self.photo_card)
        self.photo_button=QPushButton('DRONE CAM\nЗураг хүлээж байна…')
        self.photo_button.setMinimumHeight(112)
        self.photo_button.clicked.connect(self._enlarge_photo)
        layout.addWidget(self.photo_button)
        self.photo_caption=label('Автомат • хавтас хүлээж байна');layout.addWidget(self.photo_caption)
        self.overlay_timer=QTimer(self);self.overlay_timer.timeout.connect(self._position_photo)
        self.overlay_timer.start(200);self._position_photo()

    def _position_photo(self):
        self.photo_card.move(max(8,self.map.viewport().width()-254),max(8,self.map.viewport().height()-189))
        self.photo_card.raise_()

    def _choose_photo_folder(self):
        folder=QFileDialog.getExistingDirectory(self,'Дроны зургийн хавтас',str(self.photo_folder))
        if folder:
            self.photo_folder=Path(folder);self.settings.setValue('photo_folder',folder)
            self.folder_label.setText(folder);self.photo_signature=None;self._poll_drone_photos()

    def _poll_drone_photos(self):
        try:
            files=[p for p in self.photo_folder.iterdir() if p.is_file() and p.suffix.lower() in ('.jpg','.jpeg','.png','.bmp','.webp')]
            if not files:return
            path=max(files,key=lambda p:p.stat().st_mtime_ns)
            stat=path.stat();signature=(str(path),stat.st_mtime_ns,stat.st_size)
            if signature!=self.photo_signature and self._load_photo(path):self.photo_signature=signature
        except OSError:self.photo_caption.setText('Хавтаст холбогдох боломжгүй')

    def _load_photo(self,path):
        from PySide6.QtGui import QPixmap,QIcon
        from PySide6.QtCore import QSize
        pix=QPixmap(str(path))
        if pix.isNull():return False
        self.photo_path=path
        self.photo_button.setText('');self.photo_button.setIcon(QIcon(pix));self.photo_button.setIconSize(QSize(210,110))
        self.photo_caption.setText(f'● {path.name} • Дарж томруулах');self.photo_caption.setToolTip(str(path))
        return True

    def _enlarge_photo(self):
        if not self.photo_path:self._show_telemetry();return
        from PySide6.QtGui import QPixmap
        dialog=QDialog(self);dialog.setWindowTitle(self.photo_path.name);dialog.resize(1000,720)
        layout=QVBoxLayout(dialog);scroll=QScrollArea();scroll.setWidgetResizable(True)
        image=QLabel();image.setAlignment(Qt.AlignmentFlag.AlignCenter)
        pix=QPixmap(str(self.photo_path))
        image.setPixmap(pix.scaled(1500,1000,Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation))
        scroll.setWidget(image);layout.addWidget(scroll)
        close=QPushButton('Хаах');close.clicked.connect(dialog.accept);layout.addWidget(close);dialog.exec()

    def _rename_station(self):
        idx=self.station_list.currentRow()
        if idx<0:return
        station=self.map.stations[idx];old=station['id']
        name,ok=QInputDialog.getText(self,'Станцын нэр','Шинэ нэр:',text=old)
        if not ok or name.strip()==old:return
        name=name.strip()
        if not name or any(m['id']==name for m in self.db.markers()):
            QMessageBox.information(self,'Станц','Давхцахгүй нэр оруулна уу.');return
        self.db.rename_marker(old,name);station['id']=name;self._update_all();self.station_list.setCurrentRow(idx)

    def _move_station(self):
        idx=self.station_list.currentRow()
        if idx<0:return
        self.moving_station=self.map.stations[idx]['id'];self._mode('station_move')
        self.statusBar().showMessage('Станцын шинэ байрлалыг газрын зураг дээр дарна уу.')

    def _delete_station(self):
        idx=self.station_list.currentRow()
        if idx<0:return
        station=self.map.stations[idx];self.db.delete_marker(station['id']);self.map.stations.pop(idx)
        if self.moving_station==station['id']:self.moving_station=None;self._mode('pan')
        self.db.add_event('station_deleted',station=station['id']);self._update_all()
        if self.map.stations:self.station_list.setCurrentRow(min(idx,len(self.map.stations)-1))
        self.statusBar().showMessage(f"{station['id']} станцыг устгаж хадгаллаа.",5000)

    def _update_stations(self):
        selected=self.station_list.currentRow();self.station_list.blockSignals(True);self.station_list.clear()
        for station in self.map.stations:
            item=QListWidgetItem(f"{station['id']} · {station['status']}")
            item.setData(Qt.ItemDataRole.UserRole,station['id']);self.station_list.addItem(item)
        if self.map.stations:self.station_list.setCurrentRow(min(max(0,selected),len(self.map.stations)-1))
        self.station_list.blockSignals(False);self._station_selected(self.station_list.currentRow());self._update_station_alert()

    def _station_selected(self,index):
        valid=0<=index<len(self.map.stations);self.delete_station_button.setEnabled(valid)
        if not valid:self.station_info.setText('');return
        station=self.map.stations[index];lon,lat=self.map.lonlat(station['x'],station['y'])
        height=station.get('reading',{}).get('elevation_m')
        elevation=f'{height:.0f} м · NASA MOLA' if height is not None else '—'
        self.station_info.setText(f"{station['id']}\n{lon:.4f}°, {lat:.4f}°\nӨндөршил: {elevation}\nТемператур: —\nСалхи: —\nЦэнэг: —\nТэмдэглэсэн төлөв: {station['status']}")
        self.station_status.setCurrentIndex(self.station_status.findText(station['status']))

    def _sample_station(self,station):
        position=self.map.lonlat(station['x'],station['y'])
        value=self.terrain_grid.sample(position) if self.terrain_grid else None
        station['reading']={'elevation_m':value,'source':'NASA MOLA' if value is not None else None}
        self.db.save_station_reading(station['id'],station['reading'])

    def _update_station_alert(self):
        count=len(self.map.stations)
        self.station_alert.setText(f'{count} тэмдэглэсэн станц' if count else 'NASA MOLA · газрын гадаргын шинжилгээ')
        self.station_alert.setStyleSheet('padding: 10px; background: #172b39; border-radius: 8px; color:#8eb6c9;')

    def _set_station_status(self):
        idx=self.station_list.currentRow()
        if idx<0:return
        s=self.map.stations[idx]
        s['status']=self.station_status.currentData() or self.station_status.currentText()
        self.db.upsert_marker(s['id'],'station',s['x'],s['y'],s['status'])
        self.db.add_event('station_status_changed',station=s['id'],status=s['status'])
        self._update_all()
        self.station_list.setCurrentRow(idx)

    def _update_events(self):
        self.events_list.clear()
        for when,event,payload in self.db.events():
            self.events_list.addItem(f'{when}\n{event}: {payload[:180]}')

    def _clear_trail(self):
        self.db.clear_trail();self.map.trail=[];self.db.add_event('trail_cleared')
        self._update_all()

    def _update_all(self):
        self.map.render_overlay()
        self._update_routes()
        self._update_storm()
        self._update_drone()
        self._update_stations()
        self._update_events()

    def _profile_changed(self,index):
        values=(5,500,500) if index else (3,250,150)
        for widget,value in zip((self.speed_spin,self.power_spin,self.mass_spin),values):
            widget.blockSignals(True);widget.setValue(value);widget.blockSignals(False)
        self._schedule_routes()

    def _map_source_changed(self,message):
        self.map_source_status.setToolTip(message)
        if 'connected •' in message:self.map_source_status.setText('● NASA Trek · холбогдсон')
        elif 'loading' in message:self.map_source_status.setText('NASA Trek · татаж байна…')
        else:self.map_source_status.setText('NASA Trek · холболт шалгаж байна')

    def _mobility(self):
        return Mobility(self.profile_combo.currentText(),self.speed_spin.value(),
                        self.mass_spin.value(),self.power_spin.value(),.25 if self.profile_combo.currentIndex()==0 else .6)

    def _schedule_routes(self,*args):
        self.route_request+=1
        self.map.routes=[]
        self.route_state.setText('NASA MOLA · маршрут тооцоолж байна…')
        self._update_routes();self.map.render_overlay()
        self.route_debounce.start()

    def _start_job(self,key,token,function,success,error):
        job=Job(token,function);self.science_jobs[key]=job
        job.signals.finished.connect(success);job.signals.failed.connect(error)
        QThreadPool.globalInstance().start(job)

    def _calculate_routes(self):
        if self._closed:return
        token=self.route_request
        a=self.map.lonlat(*self.map.a);b=self.map.lonlat(*self.map.b);profile=self._mobility()
        if distance_km(a,b)<.001:
            self.route_state.setText('A ба B давхцаж байна');return
        # One terrain request at a time. A new click invalidates delivery immediately.
        if 'route' in self.science_jobs:
            self.route_debounce.start();return
        cache=DATA_DIR/'nasa-cache'
        def work():
            grid=fetch_terrain(a,b,cache)
            return grid,plan_routes(grid,a,b,profile)
        self._start_job('route',token,work,self._routes_ready,self._routes_failed)

    def _routes_ready(self,token,result):
        self.science_jobs.pop('route',None)
        if self._closed:return
        if token!=self.route_request:self.route_debounce.start();return
        self.terrain_grid,routes=result
        for route in routes:
            route['points']=[self.map.from_lonlat((lon+180)%360-180,lat) for lon,lat in route['lonlat']]
        self.map.routes=routes
        self.route_state.setText('NASA MOLA · тооцоо бэлэн' if routes else 'Налуугийн хязгаарт багтах маршрут олдсонгүй')
        for station in self.map.stations:self._sample_station(station)
        self._update_routes();self._update_stations();self.map.render_overlay()

    def _routes_failed(self,token,message):
        self.science_jobs.pop('route',None)
        if self._closed:return
        if token!=self.route_request:self.route_debounce.start();return
        self.route_state.setText('Өндөршлийн өгөгдөл татаж чадсангүй')
        self.route_state.setToolTip(message)
        self.statusBar().showMessage('NASA MOLA · холболтыг шалгаад A/B-г дахин сонгоно уу',7000)

    def _load_nasa_weather(self):
        if self._closed or 'weather' in self.science_jobs:return
        self._start_job('weather',0,fetch_weather,self._weather_ready,self._weather_failed)

    def _weather_ready(self,token,records):
        self.science_jobs.pop('weather',None)
        if self._closed:return
        self.map.weather_points=records
        self._update_temperature_records(records)
        def fmt(value):return '—' if value is None else f'{value:g}'
        lines=[]
        for record in records:
            lines.append(f"{record['name']}\n{record['date']} · Sol {record['sol']} · архив\nАгаар {fmt(record['min_c'])}…{fmt(record['max_c'])} °C\nГадарга {fmt(record['ground_min_c'])}…{fmt(record['ground_max_c'])} °C\nДаралт {fmt(record['pressure_pa'])} Pa\nСалхи {fmt(record['wind_mps'])} м/с")
        self.weather_label.setText('\n\n'.join(lines) or 'Хэмжилтийн өгөгдөлгүй')
        self.storm_note.setText('Шуурганы орон зайн мэдээлэлгүй' if not any(r['wind_mps'] is not None for r in records) else 'Салхины цэгэн хэмжилт · архив')
        self.map.render_overlay()

    def _update_temperature_records(self,records):
        from html import escape
        rows=[]
        for record in records:
            lo=record.get('ground_min_c');hi=record.get('ground_max_c');kind='Гадарга'
            if lo is None or hi is None:lo=record.get('min_c');hi=record.get('max_c');kind='Агаар'
            if lo is None or hi is None:continue
            rows.append(f'<b>{escape(record["name"])}</b><br>{kind} · {lo:g}…{hi:g} °C<br><span style="color:#92a6b7">{escape(record["date"])}</span>')
        self.temperature_records.setText('<br><br>'.join(rows) or 'Температурын хэмжилтгүй')

    def _weather_failed(self,token,message):
        self.science_jobs.pop('weather',None)
        if self._closed:return
        self.weather_label.setText('NASA цаг агаар · холболтгүй')
        self.weather_label.setToolTip(message)

    def _toggle_thermal(self,enabled):
        if enabled:
            self.thematic_check.setChecked(False)
            if self.thermal_tiles is None:
                layer='Mars_MO_THEMIS-IR-Day_mosaic_global_100m_v12_clon0_ly'
                url=f'https://trek.nasa.gov/tiles/Mars/EQ/{layer}/1.0.0/WMTSCapabilities.xml'
                self.thermal_tiles=NasaTiles(self.map,url,base_z=-70,opacity=.7)
                self.thermal_tiles.status_changed.connect(self.thermal_status.setText)
            else:
                self.thermal_tiles.stopped=False;self.thermal_tiles.timer.start();self.thermal_tiles.update_visible()
            for item in self.thermal_tiles.items.values():item.setVisible(True)
        elif self.thermal_tiles:
            self.thermal_tiles.stop()
            for item in self.thermal_tiles.items.values():item.setVisible(False)
            self.thermal_status.setText('')

    def _make_zone_legend(self):
        self.zone_legend=QFrame(self.map.viewport())
        self.zone_legend.setObjectName('zoneLegend')
        self.zone_legend.setStyleSheet('QFrame#zoneLegend {background:#f8faf9; border:1px solid #ced7d7; border-radius:8px;} QLabel {color:#203443; background:transparent; border:none;}')
        layout=QVBoxLayout(self.zone_legend);layout.setSpacing(6);layout.setContentsMargins(12,10,12,10)
        layout.addWidget(label('ӨНДӨРШИЛ · м',True))
        for color,text in zip(ELEVATION_COLORS,ELEVATION_LABELS):
            row=QHBoxLayout();swatch=QLabel();swatch.setFixedSize(24,12)
            swatch.setStyleSheet(f'background:{color};border:1px solid #ffffff;')
            row.addWidget(swatch);row.addWidget(label(text));layout.addLayout(row)
        source=label('NASA MOLA · ≈15 км тор');source.setStyleSheet('color:#647980;font-size:10px;')
        layout.addWidget(source);self.zone_legend.setFixedWidth(225);self.zone_legend.adjustSize()
        self.zone_legend.move(14,14);self.zone_legend.hide()

    def _toggle_thematic(self,enabled):
        if enabled:
            self.layer_checks['show_temperature'].setChecked(False)
            self.thermal_check.setChecked(False)
        if self.map.thematic_item is not None:
            self.map.thematic_item.setVisible(enabled);self.zone_legend.setVisible(enabled)
            return
        if not enabled:return
        if 'thematic' in self.science_jobs:return
        self.thematic_status.setText('NASA MOLA · бүсчлэл татаж байна…')
        self._start_job('thematic',0,lambda:fetch_global_elevation(DATA_DIR/'nasa-cache'),self._thematic_ready,self._thematic_failed)

    def _thematic_ready(self,token,result):
        self.science_jobs.pop('thematic',None)
        if self._closed:return
        self.elevation_grid,image=result;self.map.set_thematic_image(image)
        enabled=self.thematic_check.isChecked()
        self.map.thematic_item.setVisible(enabled);self.zone_legend.setVisible(enabled)
        self.zone_legend.raise_();self.thematic_status.setText('NASA MOLA · 7 бүс · ≈15 км тор')

    def _thematic_failed(self,token,message):
        self.science_jobs.pop('thematic',None)
        if self._closed:return
        self.thematic_status.setText('Өндөршлийн бүсчлэл · холболтгүй')
        self.thematic_status.setToolTip(message)

    def _show_sources(self):
        dialog=QDialog(self);dialog.setWindowTitle('Өгөгдлийн эх сурвалж');dialog.resize(680,580)
        layout=QVBoxLayout(dialog);text=QTextEdit();text.setReadOnly(True)
        text.setPlainText(
            'NASA MOLA DEM\n128 pixels/degree (~463 m at equator). Resampled to a 129×129 route grid. '
            'Global trips use coarser cells. Sub-cell rocks, crevasses and slope extremes are unresolved. '
            'A* searches the downloaded corridor; it does not prove a globally optimal or operationally safe route.\n\n'
            'https://trek.nasa.gov/mars/jpl/config/config.json\n\n'
            'Time/energy model\nSpeed is reduced by 1+(slope/8°)². Energy = base power × time + positive climbing work '
            '(mass × Mars gravity × ascent / efficiency). Profile values are mission assumptions, not NASA measurements. '
            'The safety objective adds a slope penalty and excludes slopes above 15°. “Risk” describes slope only.\n\n'
            'NASA REMS / MEDA\nDated local outreach observations at Gale / Jezero. Weather is not extrapolated globally. '
            'Point symbols use approximate mission locations, not rover tracking. Wind colors use project thresholds; '
            'animated direction indicators do not predict storm movement.\n\n'
            'https://mars.nasa.gov/rss/api/?feed=weather&category=msl&feedtype=json\n'
            'https://mars.nasa.gov/rss/api/?feed=weather&category=mars2020&feedtype=json\n\n'
            'NASA Odyssey THEMIS\nArchived daytime infrared mosaic. Image brightness is not a calibrated temperature in °C.\n\n'
            'Radiation\nCuriosity RAD observations are local. No validated spatial dose grid is configured; radiation routes and dose estimates remain unavailable.\n'
            'https://science.nasa.gov/resource/radiation-measurements-on-mars/\n\n'
            'Backend station/drone records remain separate, retaining their source and simulation labels. '
            'Mission markers describe planned positions, not NASA astronaut/hardware telemetry.')
        layout.addWidget(text);close=QPushButton('Хаах');close.clicked.connect(dialog.accept);layout.addWidget(close);dialog.exec()

    def closeEvent(self,event):
        self._closed=True
        for job in self.science_jobs.values():job.cancel()
        self.route_debounce.stop();self.science_timer.stop()
        if self.thermal_tiles:self.thermal_tiles.stop()
        self.backend.stop()
        self.map.tiles.stop()
        self.photo_timer.stop();self.storm_timer.stop();self.overlay_timer.stop()
        self.db.close()
        super().closeEvent(event)
