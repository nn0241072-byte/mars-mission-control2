`nasa_mola_arsia_64.tif` is an unmodified quantitative NASA Trek MOLA export,
retrieved 2026-11-15 UTC, for longitude -121..-119, latitude -9..-7.

Service (discovered in NASA Trek's public configuration):
https://trek.nasa.gov/mars/trekarcgis/rest/services/mola128_mola64_merge_90Nto90S_SimpleC_clon0/ImageServer

Operation: `exportImage`; query:
`bbox=-121,-9,-119,-7&bboxSR=104905&imageSR=104905&size=64,64&format=tiff&pixelType=F32&noData=-32768&interpolation=RSP_BilinearInterpolation&adjustAspectRatio=false&f=image&compression=None`

One floating-point height band, meters relative to the MOLA reference surface.
This fixture tests the real response encoding and planetary elevation sampling.
Synthetic grids in tests are explicitly test fixtures, never production data.
